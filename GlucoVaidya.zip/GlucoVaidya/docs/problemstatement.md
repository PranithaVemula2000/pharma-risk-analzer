# Problem Statement — GlucoVaidya (Hospital Helper Tool)

**Working name:** GlucoVaidya — AI-Assisted Clinical Documentation & Decision-Support Tool for Diabetes Care
**Alias used by staff:** Hospital Helper Tool

> Naming note: "GlucoVaidya" (*vaidya* = physician/healer) is a suggested name. "Hospital Helper Tool" from the original brief is kept as the internal alias throughout this doc set.

---

## 1. Context

A private, India-operated **diabetes & endocrinology hospital in Bangalore** (fictional: *Sanjeevani Diabetes & Endocrine Care, Bangalore*) runs daily OPD consultations for diabetes, thyroid disorders, and related metabolic conditions. Doctors currently record consultation advice, blood test values, medications, diagnosis, and course changes manually or in unstructured EMR text fields, with no structured tracking of:

- which national/international clinical protocol was followed,
- how a patient's medication course evolved over time,
- whether a diagnosis was later revised (false positive/negative),
- retrievable audit trail of AI-assisted or search-assisted decisions.

## 2. Problem Statement

> *Doctors at a Bangalore-based diabetes hospital need a single clinical workstation where they can record structured consultation data (symptoms, vitals, blood tests, diagnosis, medication course, and course changes), receive protocol-grounded and web-search-assisted decision support (drug selection, brand alternatives, allergy substitutes) at the point of care, and have every diagnosis, course change, and outcome tracked against measurable KPIs (e.g., Course 1 → Course 2 escalation, time-to-glycemic-control) — without the tool ever autonomously prescribing, and while remaining compliant with India's DPDP Act 2023 and applicable pharma/clinical-practice regulations.*

## 3. Objectives

1. Structured, protocol-aligned consultation capture (symptoms → tests → diagnosis → medication → course).
2. Point-of-care search assistance (Google Search) for drug identification, brand alternatives, and allergy substitution — logged, not autonomous.
3. Longitudinal KPI tracking across medication **courses** (not just single visits).
4. Coverage of the major diabetes/endocrine patient categories the hospital sees.
5. Human-in-the-loop AI: suggestions only, doctor retains final authority.
6. Governance-ready: every AI suggestion, search query, and course change is auditable (see `governance.md`).

## 4. Core Clinical Scenarios

### Scenario 1 — New Symptomatic Patient (Protocol-Guided Triage)
Patient presents with symptoms (e.g., polyuria, fatigue, blurred vision). Doctor must follow **ICMR / RSSDI (Research Society for the Study of Diabetes in India) / WHO / ADA** advisory protocols to decide: order tests, diagnose, or rule out (false-alarm/no-medication case). Tool surfaces protocol checklist + Google Search tab for symptom/medicine cross-reference.
**KPI:** time-to-diagnosis, % of visits correctly triaged to "no medication needed."

### Scenario 2 — Course Escalation on Insulin/Drug Non-Response
Patient completes prescribed **Course 1** (defined brand, dose, duration) but glucose/HbA1c remains uncontrolled. Tool must track the **Course 1 → Course 2 transition**, capture reason for change, and flag the patient for closer observation.
**KPI:** Course-1-to-Course-2 conversion rate, HbA1c delta per course, number of courses to control, time-in-observation.

### Scenario 3 — Non-Diabetic / Prediabetic Outcome
Tests come back normal or borderline. No pharmacological treatment; lifestyle/diet advice only. Tool records "ruled out" outcome distinctly from "diagnosed."
**KPI:** false-positive referral rate, prediabetic-to-diabetic conversion (longitudinal).

### Scenario 4 — Type 1 Diabetes (Insulin-Dependent)
Typically younger onset, autoantibody/ketosis markers. Insulin-only regimen; no oral hypoglycemics as first line.
**KPI:** insulin titration frequency, hypoglycemia episode count.

### Scenario 5 — Type 2 Diabetes
Most common adult-onset case. Metformin/oral hypoglycemic first-line per RSSDI/ADA guidance, insulin escalation if uncontrolled.
**KPI:** time to HbA1c < 7%, medication adherence proxy.

### Scenario 6 — Type 3c / Secondary Diabetes (Pancreatic/Other Cause)
Diabetes secondary to pancreatitis, steroid use, or other endocrine disorder. Requires specialist referral flag, not standard T2DM protocol.
**KPI:** correct referral rate, misclassification-as-T2DM rate.

### Scenario 7 — Gestational Diabetes / Pregnancy
Pregnant patient with abnormal glucose tolerance test. Only **insulin** is generally safe (most oral agents contraindicated). Requires OB-GYN coordination flag.
**KPI:** trimester-wise glucose control, adverse-outcome flag rate.

### Scenario 8 — Diabetes + Hyperthyroidism Comorbidity
Hyperthyroidism can worsen glycemic control. Tool must flag drug-interaction and dosage-timing considerations.
**KPI:** comorbidity-flagged consultations, TSH/glucose co-tracking.

### Scenario 9 — Diabetes + Hypothyroidism Comorbidity
Levothyroxine–metformin timing/absorption interactions. Tool prompts dosage-timing guidance via search/protocol reference.
**KPI:** interaction-alert acknowledgment rate.

### Scenario 10 — Drug Allergy / Adverse Reaction → Brand Substitution
Patient reacts to prescribed brand (e.g., sulfa-based drug). Doctor uses the **Google Search tab** to find an alternate brand/molecule with the same therapeutic class minus the allergen.
**KPI:** time-to-alternate-brand decision, repeat-allergy-incident rate.

### Scenario 11 (bonus) — Renal Impairment
Low eGFR patient; metformin contraindicated/dose-capped. Tool flags renal-adjusted drug list.
**KPI:** contraindicated-prescription near-miss rate (caught before finalizing).

### Scenario 12 (bonus) — Elderly / Hypoglycemia-Risk Patient
Conservative titration required; tool flags high hypoglycemia-risk profile before suggesting dose increases.
**KPI:** hypoglycemia event rate in >65 age cohort.

## 5. Google Search Tab — Purpose

An in-tool Google Search panel assists the doctor (not the patient, not autonomously) with:
- Identifying **medicine brand names** available in India for a given molecule/protocol step.
- Finding **alternate brands** when the patient is allergic or the brand is unavailable.
- Cross-checking **drug-drug / drug-condition interactions** (e.g., thyroid + diabetes drugs).
- Looking up **updated national/WHO advisory protocol** references.
- Every search query + clicked result is logged against the consultation for audit (see `governance.md` §11) and **must never include patient-identifying text** in the query string.

## 6. Non-Goals / Out of Scope

- The tool does **not** autonomously prescribe, dose, or finalize a diagnosis — it only suggests; the doctor signs off.
- Not a replacement for lab/pathology systems — it consumes test results, doesn't generate them.
- Not intended for patient self-use (clinician-facing only).

## 7. Success Criteria

- All 10+ scenarios have a structured data path (see `sample_patient_data.csv`).
- Every course change is traceable (Course N → Course N+1, with reason).
- Every AI suggestion and search query is logged (see `governance.md`, `Algent.md`).
- KPIs in §4 are computable directly from stored consultation records.
