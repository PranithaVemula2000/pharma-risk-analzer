# Algent.md — GlucoVaidya AI Agent Design

This document defines the online clinical-support agent embedded in the Hospital Helper Tool. The agent assists the doctor during consultation entry, course-change decisions, and data-upload review — it never acts autonomously on the patient record.

Structure follows the standard agent lifecycle: **Goal → Planning → LLM → Memory → Tool → Evaluation → Observation**, wrapped around the Google Search engine and the doctor's data uploads (blood test reports, prior prescriptions).

---

## 1. Goal

**Primary goal:** Given the current consultation state (symptoms, uploaded test data, diagnosis-so-far, medication/course history), produce a **grounded, cited, advisory suggestion** for the doctor covering one or more of:

- Which national/WHO protocol step applies next (test to order / diagnosis to consider / rule-out).
- Whether the current medication course should continue, escalate, or switch (Course N → Course N+1), with reasoning tied to KPI thresholds (e.g., HbA1c not improved after course duration).
- Brand/molecule alternatives if an allergy or non-availability is flagged.
- Interaction warnings across comorbidities (thyroid, pregnancy, renal).
- A structured "further action" recommendation (e.g., "refer to endocrinologist," "repeat HbA1c in 6 weeks," "no medication indicated").

**Hard constraint:** never output a final diagnosis or prescription as fact — always phrased as a suggestion with source, and always requires doctor accept/edit/reject.

## 2. Planning

The agent uses a **fixed-step ReAct-style plan**, not open-ended autonomy, so behavior stays auditable in a clinical setting:

1. **Parse consultation state** — symptoms, latest vitals/labs, current diagnosis label, active course (brand, dose, day count).
2. **Classify scenario** — map to one of the problem-statement scenarios (new-patient triage / course-escalation / comorbidity / allergy-substitution / etc.) using rules first, LLM classification as fallback.
3. **Decide if grounding is sufficient** — if internal protocol knowledge (RSSDI/WHO snippets in memory) covers it, skip search; if brand availability / allergy-alternative / latest-advisory is needed, plan a **Google Search tool call**.
4. **Retrieve** — pull relevant protocol snippets from memory + (optionally) search results.
5. **Compose suggestion** — LLM drafts the advisory suggestion with inline citations (protocol name/section or search result link).
6. **Self-check** — verify the suggestion doesn't state an unsupported fact (basic groundedness check against retrieved context before returning).
7. **Present to doctor** — doctor accepts / edits / rejects; decision is written back to memory as feedback.

This plan re-runs on every material state change (new lab upload, course-duration elapsed, doctor edits diagnosis) — not continuously, to avoid unnecessary LLM/search calls (cost + governance minimization, see `governance.md` §6).

**Additional fixed-purpose agents:** three more single-purpose agents (case
summary for the patient file, translation of the suggestion for patient
communication, and grounded follow-up Q&A about the current case) follow the
same fixed-step, auditable design — each is a single LLM call over the same
consultation context, never open-ended, and each is logged to the trace log
like the main suggestion agent. They share the exact same
Groq → OpenAI → OpenRouter → Demo Mode provider chain and API keys as the main
suggestion agent — no separate credential or provider integration.

## 3. LLM

- **Role:** reasoning/classification + drafting the cited suggestion text. Not the source of clinical truth — a synthesizer over retrieved protocol context and search snippets.
- **Model:** configurable; suggested default `openai/gpt-oss-120b` via Groq (or OpenRouter, if the team standardizes on OpenRouter for multi-model flexibility — see note below), temperature 0.1–0.2 for deterministic, low-fabrication output.
- **Prompting rules:**
  - System prompt fixes the "advisory only, cite sources, never invent dosage/brand facts" constraint (mirrors `governance.md` §10).
  - Context window = current consultation state + retrieved memory snippets + (if used) search results, never the full historical corpus.
- **Note on provider:** if the team switches the LLM call to OpenRouter (as flagged separately), only the LLM client wrapper changes — planning/memory/tool/evaluation layers are provider-agnostic by design.

## 4. Memory

Two memory tiers, kept separate for governance clarity:

| Tier | Contents | Scope |
|---|---|---|
| **Short-term (session/working memory)** | Current consultation's parsed state, in-progress plan steps, retrieved snippets for this turn | Cleared at end of consultation |
| **Long-term (patient longitudinal memory)** | Course history (Course 1 → Course N with dates/outcomes), prior diagnoses, comorbidity flags, prior allergy/substitution events | Persisted per patient, keyed to patient ID, access-controlled per `governance.md` §12 |
| **Reference memory (static)** | Cached protocol snippets (ICMR/RSSDI/WHO/ADA summaries), CDSCO-approved brand/molecule mapping | Read-only, periodically refreshed, shared across patients |

Long-term memory is what makes **Scenario 2's KPI tracking** possible: the agent reads prior course entries from long-term memory to detect "Course 1 duration elapsed, HbA1c unchanged → recommend Course 2 evaluation," rather than treating each visit independently.

## 5. Tool — One MCP Server

To keep the tool surface minimal and auditable (per the brief: "one MCP is enough"), the agent is given a **single MCP server** exposing a small, fixed set of functions:

```
mcp-server: clinical-support-tools
├── google_search(query: str, context_hint: str) -> [{title, url, snippet}]
│     - query MUST be de-identified before this call (governance.md §11)
├── upload_ingest(file: bytes, type: "lab_report" | "prior_prescription") -> structured_data
│     - parses uploaded blood test / prior Rx into structured fields
├── protocol_lookup(condition: str) -> [{source, section, text}]
│     - reads from reference memory (ICMR/RSSDI/WHO/ADA snippets)
└── kpi_query(patient_id: str, metric: str) -> value
      - reads course-history KPIs from long-term memory (recall, course-conversion rate, etc.)
```

All four capabilities live behind **one MCP server** so the agent's tool-access footprint is a single reviewable surface for the hospital's security/governance team, rather than four separately-governed integrations. `google_search` is the only function that leaves the hospital's network boundary — it is therefore the one function whose inputs are scrubbed per `governance.md` §11 before the call is made, and whose query+result is logged for audit.

## 6. Evaluation

Two evaluation layers, using the same heuristic-evaluation philosophy common to RAG systems (retrieval/context-relevance + groundedness/faithfulness scoring), applied here to agent *suggestions* rather than RAG *answers*:

- **Groundedness/Faithfulness:** does the suggestion's cited claim actually appear in the retrieved protocol snippet or search result? (LLM-judge or rule-based span match)
- **Context Relevance:** was the retrieved protocol/search snippet actually relevant to the classified scenario?
- **Suggestion Acceptance Rate:** % of agent suggestions the doctor accepts as-is vs. edits vs. rejects — the single most important real-world signal.
- **KPI-tracking correctness:** does the agent correctly detect Course-N transitions and comorbidity flags against a labeled test set of synthetic consultations (`sample_patient_data.csv`)?
- **Latency:** plan → suggestion round-trip time, split by whether a search call was needed.
- **Escalation/false-negative check:** did the agent ever recommend "no medication" when ground truth (in test data) says medication was needed, or fail to flag a course-escalation trigger? — tracked as a hard safety metric, reported separately from soft relevance metrics, per `governance.md`'s "never present estimated metrics as exact truth."

All evaluation metrics are explicitly labeled **heuristic/LLM-assisted** unless computed against labeled ground truth, consistent with the project's evaluation transparency requirement.

## 7. Observation (Observability)

Every agent run emits a structured trace, stored in the audit-log tier described in `governance.md` §10 and §12:

```
trace_id, patient_id (hashed for logs), timestamp,
scenario_classified, plan_steps[], 
tool_calls[ {tool, input(de-identified), output, latency} ],
llm_prompt_ref, llm_output, groundedness_score,
doctor_action: accepted | edited | rejected,
final_record_delta
```

- Traces are the basis for both the Evaluation tab (KPI 6 above) and governance audit requests.
- Any `google_search` call is separately flagged in the trace (external-network boundary crossed) for compliance review.
- Traces containing PHI are access-restricted the same as clinical records (§12 of `governance.md`); aggregated/anonymized trace statistics feed the Evaluation dashboard tab.

## 8. End-to-End Flow Summary

```
Doctor enters symptoms/uploads labs
        │
        ▼
[Goal] classify need → [Planning] fixed ReAct steps
        │
        ▼
[Memory: reference] protocol snippet   [Memory: long-term] course history
        │                                       │
        └──────────────┬────────────────────────┘
                        ▼
        need external info? ──yes──▶ [Tool/MCP: google_search] (de-identified)
                        │no
                        ▼
              [LLM] draft cited suggestion
                        ▼
              [Evaluation] groundedness self-check
                        ▼
        Doctor reviews → accept / edit / reject
                        ▼
        [Observation] trace logged, [Memory: long-term] updated
                        ▼
        Suggestion for further action shown (repeat test / refer / escalate course / no medication)
```
