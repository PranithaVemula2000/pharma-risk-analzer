# Governance.md — GlucoVaidya (Hospital Helper Tool)

> **Assumption flagged:** the brief refers to "India AOLLO Pharms rules." This does not match a known statutory body. This document assumes it means one (or a combination) of: **Apollo Pharmacy / retail-pharmacy dispensing compliance norms**, and/or the statutory **CDSCO (Central Drugs Standard Control Organisation)** and **Drugs & Cosmetics Act, 1940 / Rules 1945** framework that governs how brand/molecule information may be surfaced to a prescriber in India. Please confirm/correct the exact body if this assumption is wrong — the pharma-compliance section below is written to be easily re-pointed.

## 1. Purpose & Scope

This document governs how the GlucoVaidya tool — used by doctors at a Bangalore diabetes hospital — handles patient health data, AI/agent-generated suggestions, and external search results, under Indian law and clinical-practice norms. It applies to: consultation records, blood test data, medication/course data, AI agent outputs (`Algent.md`), and Google Search interactions.

## 2. Applicable Regulatory Framework

| Domain | Regulation | Relevance |
|---|---|---|
| Personal/health data | **Digital Personal Data Protection Act, 2023 (DPDP Act)** + draft DPDP Rules | Patient health data = sensitive personal data; consent, purpose limitation, breach notification |
| IT / electronic records | **IT Act, 2000** + IT (Reasonable Security Practices) Rules, 2011 | Security safeguards for electronic health records |
| Clinical practice | **National Medical Commission (NMC) Act, 2019** + **Telemedicine Practice Guidelines, 2020** | Doctor remains sole decision-maker; AI is advisory only |
| Drugs / pharma | **Drugs and Cosmetics Act, 1940 & Rules, 1945**; **CDSCO** brand/molecule approvals | Brand-substitution suggestions must reference CDSCO-approved alternatives only |
| Retail pharmacy dispensing (assumption) | Apollo Pharmacy / retail chain dispensing SOPs | If tool suggests "alternate brand," suggestion must be checked against actual retail availability/SOP before being handed to patient |
| Health data interoperability | **Ayushman Bharat Digital Mission (ABDM/NDHM)** data standards | If hospital integrates with ABDM, patient health IDs and records must follow ABDM data-exchange consent architecture |
| Diabetes clinical protocol | ICMR / RSSDI / WHO / ADA advisory guidelines | Referenced as *clinical* protocol, not legal governance, but cited for auditability of AI suggestions |

## 3. Data Classification

- **Sensitive Personal Data (DPDP Act):** diagnosis, blood test results, medication history, thyroid/pregnancy status — all classified as sensitive health data.
- **PII:** patient name, age, gender, contact details, patient ID.
- **Non-personal/operational data:** aggregated KPIs, course-conversion rates, anonymized evaluation metrics — may be used for model evaluation without additional consent, provided re-identification risk is assessed as negligible.

## 4. Roles Under DPDP Act

- **Data Fiduciary:** the hospital (Sanjeevani Diabetes & Endocrine Care) — determines purpose/means of processing.
- **Data Processor:** the GlucoVaidya tool/vendor — processes data on the hospital's behalf, under contract.
- **Data Principal:** the patient.
- **Consent Manager (if applicable):** required if data is shared cross-institution (e.g., referral to a specialist).

## 5. Consent Management

- Explicit, itemized consent at registration: (a) clinical record-keeping, (b) AI-assisted decision support, (c) use of anonymized data for internal quality/KPI evaluation.
- Consent must be **specific** — a generic "I agree to terms" is insufficient under DPDP.
- Right to withdraw consent must not block ongoing emergency care but does halt further AI-suggestion generation for that patient's future visits.

## 6. Data Minimization & Purpose Limitation

- The AI agent and Google Search tool must receive **only the minimum data needed** for the task (e.g., "metformin alternative sulfa allergy" — molecule/class only, never patient name/ID in the search query).
- Search query text sent to Google **must be scrubbed** of patient identifiers, exact DOB, address, or unique test values that could re-identify the patient in search logs.

## 7. Data Localization & Storage

- Primary health records stored on servers located in India (DPDP does not mandate localization for all data, but health data as a sensitive category should default to in-India storage pending sectoral rules).
- Vector store / embeddings / KPI database: same localization posture as source records.
- No raw patient text sent to non-India-hosted third-party LLM/search infra without a documented data-processing agreement and, where feasible, anonymization/redaction pre-transmission.

## 8. Retention & Deletion

- Clinical records: retained per applicable medical-records retention norms (commonly cited as minimum 3 years for OPD records; longer for specific categories — hospital's medical records policy governs the exact figure).
- AI interaction logs (search queries, suggestion logs): retained for audit purposes for a defined period (e.g., 2 years), then purged or anonymized.
- Patient may request erasure subject to statutory medical-record retention overriding erasure where legally required.

## 9. Breach Notification

- Any data breach involving patient health data must be reported per DPDP Act breach-notification requirements (to the Data Protection Board and affected patients) — timeline per the Act/Rules once notified thresholds are finalized; hospital's internal SOP should default to prompt (e.g., within 72 hours of discovery) notification pending final Rules.

## 10. AI / Agent-Specific Governance

- **No autonomous prescribing.** Every AI/LLM suggestion (diagnosis hint, drug suggestion, course-change flag) is advisory; the doctor must explicitly accept/override before it becomes part of the medical record.
- **Grounding requirement:** AI suggestions must cite the protocol/source (ICMR/RSSDI/WHO/ADA or search result) used — no un-sourced generative claims presented as fact.
- **Fabrication guard:** if the agent lacks sufficient grounded context, it must state uncertainty rather than invent a dosage, brand, or interaction fact.
- **Audit trail:** every agent action (planning step, tool call, search query, suggestion, doctor's accept/override) is logged with timestamp — see `Algent.md` §Observation.

## 11. Google Search Tool Governance

- Search queries are **de-identified** before being sent (molecule/class/symptom-level only).
- Search results are **logged** (query, result links used, timestamp, doctor who triggered it) but the underlying webpage content is not stored beyond what's needed for the consultation note.
- Search is a **decision-support aid**, not a diagnostic source — results must be corroborated against protocol before acting.
- No advertising-influenced or unverified retail source should be used for drug-safety claims; prefer CDSCO/NPPA/manufacturer/PubMed-class sources when available.

## 12. Access Control & Audit

- Role-based access: doctors (full read/write on their patients), admin (aggregate KPI/evaluation view only, no raw PHI by default), IT/DPO (audit-log access only).
- Every read/write/AI-suggestion/search event is attributable to a logged-in clinician (no shared logins).

## 13. Grievance Redressal / Data Protection Officer (DPO)

- Hospital designates a DPO/grievance officer for DPDP-related patient complaints.
- Patients may request: data access, correction, erasure (subject to §8), and consent-withdrawal, routed through the DPO.

## 14. Non-Compliance & Penalties (Reference Only)

- DPDP Act, 2023 prescribes financial penalties up to ₹250 crore for significant data-breach/non-compliance findings by the Data Protection Board — cited here for internal risk-awareness, not as legal advice.
- This document is an internal governance guide, **not** a substitute for legal counsel; final policy should be reviewed by the hospital's legal/compliance team before production use.
