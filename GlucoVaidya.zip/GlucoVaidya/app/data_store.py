"""Load consultation/course history from CSV and group it per patient."""

from __future__ import annotations

import math

import pandas as pd

from app.models import PatientVisit


def _clean_str(value) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    return str(value).strip()


def _clean_float(value) -> float | None:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(f) else f


def _clean_int(value, default: int = 0) -> int:
    f = _clean_float(value)
    return default if f is None else int(f)


def _clean_bool(value) -> bool:
    return _clean_str(value).strip().lower() in {"yes", "true", "1"}


def _row_to_visit(row: pd.Series) -> PatientVisit:
    return PatientVisit(
        patient_id=_clean_str(row.get("patient_id")),
        visit_date=_clean_str(row.get("visit_date")),
        age=_clean_int(row.get("age")) or None,
        gender=_clean_str(row.get("gender")),
        diagnosis_type=_clean_str(row.get("diagnosis_type")),
        comorbidity=_clean_str(row.get("comorbidity")),
        symptoms=_clean_str(row.get("symptoms")),
        fasting_glucose_mgdl=_clean_float(row.get("fasting_glucose_mgdl")),
        pp_glucose_mgdl=_clean_float(row.get("pp_glucose_mgdl")),
        hba1c_percent=_clean_float(row.get("hba1c_percent")),
        tsh_miu_l=_clean_float(row.get("tsh_miu_l")),
        medication_brand=_clean_str(row.get("medication_brand")),
        generic_name=_clean_str(row.get("generic_name")),
        dosage=_clean_str(row.get("dosage")),
        course_number=_clean_int(row.get("course_number")),
        course_start_date=_clean_str(row.get("course_start_date")),
        course_duration_days=_clean_int(row.get("course_duration_days")),
        allergy_flag=_clean_bool(row.get("allergy_flag")),
        alternate_brand_suggested=_clean_str(row.get("alternate_brand_suggested")),
        google_search_used=_clean_bool(row.get("google_search_used")),
        protocol_reference=_clean_str(row.get("protocol_reference")),
        doctor_notes=_clean_str(row.get("doctor_notes")),
        outcome_status=_clean_str(row.get("outcome_status")),
        followup_required=_clean_bool(row.get("followup_required")),
        followup_date=_clean_str(row.get("followup_date")),
    )


def load_patient_visits(csv_path: str) -> list[PatientVisit]:
    """Read the consultation CSV into a list of PatientVisit records."""
    df = pd.read_csv(csv_path)
    return [_row_to_visit(row) for _, row in df.iterrows()]


def get_patient_ids(visits: list[PatientVisit]) -> list[str]:
    return sorted({v.patient_id for v in visits if v.patient_id})


def get_history(visits: list[PatientVisit], patient_id: str) -> list[PatientVisit]:
    """All visits for one patient, sorted by course number then visit date."""
    matching = [v for v in visits if v.patient_id == patient_id]
    return sorted(matching, key=lambda v: (v.course_number, v.visit_date))
