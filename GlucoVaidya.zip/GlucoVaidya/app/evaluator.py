"""Lightweight, explicitly-heuristic evaluation of an AI suggestion.

Not a substitute for clinical judgment or ground-truth evaluation - these are
keyword/substring-overlap heuristics only, labeled as such in the UI.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EvaluationResult:
    groundedness: float | None  # heuristic: fraction of context values echoed back in the suggestion
    relevance: float | None  # heuristic: whether the diagnosis category is addressed
    is_heuristic: bool = True


def evaluate_suggestion(suggestion_text: str, context: dict) -> EvaluationResult:
    text_lower = suggestion_text.lower()
    values = [str(v).lower() for v in context.values() if v not in (None, "", [])]

    groundedness = round(sum(1 for v in values if v in text_lower) / len(values), 3) if values else None

    diagnosis = str(context.get("diagnosis_type") or "").lower()
    relevance = None
    if diagnosis:
        relevance = 1.0 if diagnosis in text_lower else 0.0

    return EvaluationResult(groundedness=groundedness, relevance=relevance)
