"""Data model for a single consultation/visit row, mirroring data/sample_patient_data.csv."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PatientVisit:
    patient_id: str
    visit_date: str
    age: int | None
    gender: str
    diagnosis_type: str
    comorbidity: str
    symptoms: str
    fasting_glucose_mgdl: float | None
    pp_glucose_mgdl: float | None
    hba1c_percent: float | None
    tsh_miu_l: float | None
    medication_brand: str
    generic_name: str
    dosage: str
    course_number: int
    course_start_date: str
    course_duration_days: int
    allergy_flag: bool
    alternate_brand_suggested: str
    google_search_used: bool
    protocol_reference: str
    doctor_notes: str
    outcome_status: str
    followup_required: bool
    followup_date: str
