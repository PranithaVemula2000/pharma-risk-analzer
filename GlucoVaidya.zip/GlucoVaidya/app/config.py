"""Central configuration for GlucoVaidya: env-driven, single source of truth."""

from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Config:
    """Tunable constants for the LLM suggestion call, search call, and KPI logic."""

    # Generation (Groq, OpenAI-compatible API, free tier — tried first when configured)
    groq_base_url: str = "https://api.groq.com/openai/v1"
    groq_model_name: str = "openai/gpt-oss-120b"
    groq_max_output_tokens: int = 700

    # Generation (OpenAI direct — tried if Groq isn't configured)
    openai_model_name: str = "gpt-4o-mini"
    openai_max_output_tokens: int = 700

    # Generation (OpenRouter, OpenAI-compatible API — tried if OpenAI isn't configured)
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    openrouter_model_name: str = "openai/gpt-oss-120b"
    # Tried in order after openrouter_model_name if a model is blocked/unavailable
    # (e.g. an OpenRouter account guardrail or a temporarily de-listed endpoint).
    openrouter_fallback_models: tuple[str, ...] = (
        "meta-llama/llama-3.1-8b-instruct:free",
        "google/gemma-2-9b-it:free",
        "mistralai/mistral-7b-instruct:free",
    )
    openrouter_temperature: float = 0.15
    openrouter_max_output_tokens: int = 700
    openrouter_timeout_seconds: float = 30.0

    # Serper (Google Search API wrapper, has a free tier: https://serper.dev)
    serper_endpoint: str = "https://google.serper.dev/search"
    google_search_timeout_seconds: float = 10.0
    default_search_results: int = 5

    # KPI / course tracking
    hba1c_improvement_threshold: float = 0.3  # min drop (percentage points) counted as "improving"

    insufficient_context_message: str = (
        "Not enough consultation data has been entered to generate a grounded suggestion."
    )

    @property
    def groq_api_key(self) -> str | None:
        return os.environ.get("GROQ_API_KEY") or None

    @property
    def openai_api_key(self) -> str | None:
        return os.environ.get("OPENAI_API_KEY") or None

    @property
    def openrouter_api_key(self) -> str | None:
        return os.environ.get("OPENROUTER_API_KEY") or None

    @property
    def serper_api_key(self) -> str | None:
        return os.environ.get("SERPER_API_KEY") or None


CONFIG = Config()
