"""Streamlit entrypoint: GlucoVaidya — Diabetes Clinical Assistant (Hospital Helper Tool)."""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import CONFIG
from app.data_store import get_history, get_patient_ids, load_patient_visits
from app.evaluator import evaluate_suggestion
from app.kpi import compute_course_kpis, latest_course_needs_escalation
from app import tracing
from app import memory_index
from app.llm_client import (
    LLMUnavailableError,
    answer_followup_question,
    generate_case_summary,
    generate_suggestion,
    translate_text,
)
from app.models import PatientVisit
from app.pdf_export import build_case_summary_pdf
from app.search_client import SearchUnavailableError, deidentify_query, search

TRANSLATE_LANGUAGES = [
    "Hindi",
    "Tamil",
    "Telugu",
    "Kannada",
    "Bengali",
    "Marathi",
    "Malayalam",
    "Gujarati",
    "Punjabi",
    "Odia",
]

CSV_PATH = Path(__file__).resolve().parent.parent / "data" / "sample_patient_data.csv"
DIAGNOSIS_OPTIONS = [
    "ruled_out_non_diabetic",
    "prediabetic",
    "type1",
    "type2",
    "type3c_secondary",
    "gestational",
]

st.set_page_config(page_title="GlucoVaidya", page_icon="\U0001FA7A", layout="wide")

LIGHT_CSS = """
<style>
:root { color-scheme: light; }
.stApp { background-color: #f7f9fc; }
.marquee-wrap {
    background: linear-gradient(90deg, #0f766e, #0d9488);
    color: #ffffff; padding: 6px 0; border-radius: 6px; margin-bottom: 1rem;
    overflow: hidden; white-space: nowrap;
}
.marquee-wrap span {
    display: inline-block; padding-left: 100%;
    animation: marquee 16s linear infinite;
    font-weight: 600; letter-spacing: 0.05em;
}
@keyframes marquee {
    0% { transform: translate(0, 0); }
    100% { transform: translate(-100%, 0); }
}
.kpi-card {
    background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px;
    padding: 14px 16px; text-align: center; box-shadow: 0 1px 2px rgba(0,0,0,0.04);
}
.kpi-value { font-size: 1.4rem; font-weight: 700; color: #0d9488; }
.kpi-label { font-size: 0.78rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.04em; }
.demo-banner {
    background: #fff7ed; color: #9a3412; border: 1px solid #fed7aa; border-radius: 6px;
    padding: 6px 10px; margin-bottom: 8px; font-size: 0.85rem;
}
.search-bar-wrap {
    background: #ffffff; border: 1px solid #cbd5e1; border-radius: 999px;
    padding: 4px 6px 4px 18px; margin-bottom: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}
.search-bar-wrap div[data-testid="stTextInput"] input {
    border: none !important; box-shadow: none !important; font-size: 1.05rem;
}
.search-bar-wrap button {
    border-radius: 999px !important; background: #0d9488 !important; color: #fff !important;
    border: none !important;
}
</style>
"""

st.markdown(LIGHT_CSS, unsafe_allow_html=True)
st.markdown(
    '<div class="marquee-wrap"><span>&nbsp;&nbsp;&nbsp;&nbsp; GlucoVaidya — Hospital Helper Tool '
    "&nbsp;&nbsp;&nbsp;&nbsp; Advisory Only — Doctor Confirms All Suggestions "
    "&nbsp;&nbsp;&nbsp;&nbsp; GlucoVaidya — Hospital Helper Tool</span></div>",
    unsafe_allow_html=True,
)
st.title("GlucoVaidya — Diabetes Clinical Assistant")
st.caption("Sanjeevani Diabetes & Endocrine Care, Bangalore (fictional demo hospital)")


@st.cache_data
def _load_visits(path: str) -> list[PatientVisit]:
    return load_patient_visits(path)


all_visits = _load_visits(str(CSV_PATH))

for key, default in {
    "consultation_context": {},
    "session_visits": [],
    "last_suggestion": None,
    "last_suggestion_trace_id": None,
    "last_search": None,
    "suggestion_error": None,
    "search_error": None,
    "last_case_summary": None,
    "last_translation": None,
    "followup_qa": [],
}.items():
    if key not in st.session_state:
        st.session_state[key] = default

with st.sidebar:
    st.header("Configuration")

    st.subheader("Groq (LLM, free tier)")
    if CONFIG.groq_api_key:
        st.success("GROQ_API_KEY detected — tried first for suggestions.")
    else:
        st.warning("GROQ_API_KEY not set.")

    st.subheader("OpenAI (LLM fallback)")
    if CONFIG.openai_api_key:
        st.success("OPENAI_API_KEY detected.")
    else:
        st.warning("OPENAI_API_KEY not set.")

    st.subheader("OpenRouter (LLM fallback)")
    if CONFIG.openrouter_api_key:
        st.success("OPENROUTER_API_KEY detected.")
    else:
        st.warning("OPENROUTER_API_KEY not set.")

    if not (CONFIG.groq_api_key or CONFIG.openai_api_key or CONFIG.openrouter_api_key):
        st.warning("No LLM key set — Demo Mode will be used automatically.")
    demo_mode_llm = st.checkbox(
        "Demo Mode (LLM) — no API calls",
        value=not bool(CONFIG.groq_api_key or CONFIG.openai_api_key or CONFIG.openrouter_api_key),
        help="When on, suggestions are generated locally from the consultation context, with no network call.",
    )
    st.caption(
        "The Case Summary, Translate, and follow-up Q&A agents reuse these same "
        "Groq/OpenAI/OpenRouter keys — no separate key needed."
    )

    st.divider()
    st.subheader("Google Search (via Serper)")
    if CONFIG.serper_api_key:
        st.success("SERPER_API_KEY detected.")
    else:
        st.warning("SERPER_API_KEY not set — Demo Mode will be used automatically.")
    demo_mode_search = st.checkbox(
        "Demo Mode (Search) — no API calls",
        value=not bool(CONFIG.serper_api_key),
        help="When on, a canned placeholder result list is shown instead of a real Serper search call.",
    )

# ---- Top search bar: always visible, on every tab, type-and-Enter to search ----
_context_for_default = st.session_state["consultation_context"]
_default_query = ""
if _context_for_default:
    if _context_for_default.get("allergy_flag"):
        _default_query = f"{_context_for_default.get('medication_brand', '')} alternative brand allergy India".strip()
    else:
        _default_query = f"{_context_for_default.get('diagnosis_type', '')} treatment protocol India".strip()

st.markdown('<div class="search-bar-wrap">', unsafe_allow_html=True)
with st.form("top_search_form", clear_on_submit=False):
    search_col, button_col = st.columns([6, 1])
    with search_col:
        query_input = st.text_input(
            "Doctor search",
            value=_default_query,
            placeholder="🔍 Search medicine brands, alternatives, protocols... (type and press Enter)",
            label_visibility="collapsed",
        )
    with button_col:
        search_clicked = st.form_submit_button("Search", use_container_width=True)
st.markdown("</div>", unsafe_allow_html=True)

if search_clicked and query_input:
    _search_patient_id = st.session_state["consultation_context"].get("patient_id")
    try:
        response = search(query_input, demo_mode=demo_mode_search)
        st.session_state["last_search"] = response
        st.session_state["search_error"] = None
        tracing.append_trace(
            tracing.TraceEvent(
                trace_id=tracing.new_trace_id(),
                timestamp=tracing.now_iso(),
                event_type="search",
                patient_id_hash=tracing.hash_patient_id(_search_patient_id),
                provider="serper" if not response.is_demo else "demo",
                is_demo=response.is_demo,
                latency_seconds=response.latency_seconds,
                status="success",
                detail=response.query,
            )
        )
    except SearchUnavailableError as exc:
        st.session_state["last_search"] = None
        st.session_state["search_error"] = str(exc)
        tracing.append_trace(
            tracing.TraceEvent(
                trace_id=tracing.new_trace_id(),
                timestamp=tracing.now_iso(),
                event_type="search",
                patient_id_hash=tracing.hash_patient_id(_search_patient_id),
                provider="serper",
                is_demo=demo_mode_search,
                latency_seconds=0.0,
                status="error",
                detail=deidentify_query(query_input),
                error=str(exc),
            )
        )

if st.session_state["search_error"]:
    st.error(st.session_state["search_error"])
elif st.session_state["last_search"]:
    response = st.session_state["last_search"]
    with st.container(border=True):
        if response.is_demo:
            st.markdown(
                '<div class="demo-banner">Demo Mode — no Serper search API call was made.</div>',
                unsafe_allow_html=True,
            )
        st.caption(f"De-identified query sent: \"{response.query}\" · Latency: {response.latency_seconds:.3f}s")
        for r in response.results:
            st.markdown(f"**[{r.title}]({r.url})**")
            st.caption(r.snippet)

# ---- Top KPI dashboard (over the full loaded dataset) ----
patient_ids = get_patient_ids(all_visits)
total_courses_tracked = sum(len(get_history(all_visits, pid)) for pid in patient_ids)
overall_escalations, overall_transitions = 0, 0
for pid in patient_ids:
    kpis = compute_course_kpis(get_history(all_visits, pid))
    overall_transitions += len(kpis.transitions)
    overall_escalations += sum(1 for t in kpis.transitions if t.escalation_flagged)
overall_escalation_rate = round(overall_escalations / overall_transitions, 2) if overall_transitions else 0.0
last_suggestion_latency = (
    round(st.session_state["last_suggestion"].latency_seconds, 3) if st.session_state["last_suggestion"] else 0.0
)

kpis_top = [
    ("Patients Loaded", len(patient_ids)),
    ("Courses Tracked", total_courses_tracked),
    ("Escalation Rate", overall_escalation_rate),
    ("Last Suggestion Latency (s)", last_suggestion_latency),
]
kpi_cols = st.columns(len(kpis_top))
for col, (label, value) in zip(kpi_cols, kpis_top):
    col.markdown(
        f'<div class="kpi-card"><div class="kpi-value">{value}</div>'
        f'<div class="kpi-label">{label}</div></div>',
        unsafe_allow_html=True,
    )

tabs = st.tabs(
    [
        "Consultation",
        "Course Tracking",
        "AI Suggestion",
        "Evaluation & KPIs",
        "Observability",
        "Data Preview",
        "Case Summary",
        "Translate",
    ]
)

# ---- Tab 1: Consultation ----
with tabs[0]:
    st.subheader("Consultation entry")
    patient_choice = st.selectbox("Patient", ["New patient"] + patient_ids, key="patient_choice")

    prior_history = get_history(all_visits, patient_choice) if patient_choice != "New patient" else []
    latest_prior = prior_history[-1] if prior_history else None

    col1, col2 = st.columns(2)
    with col1:
        diagnosis_type = st.selectbox(
            "Diagnosis category",
            DIAGNOSIS_OPTIONS,
            index=DIAGNOSIS_OPTIONS.index(latest_prior.diagnosis_type) if latest_prior and latest_prior.diagnosis_type in DIAGNOSIS_OPTIONS else 3,
        )
        comorbidity = st.text_input("Comorbidity (e.g. hyperthyroid, pregnancy, ckd)", value=latest_prior.comorbidity if latest_prior else "")
        symptoms = st.text_area("Symptoms", value=latest_prior.symptoms if latest_prior else "")
        allergy_flag = st.checkbox("Known drug allergy", value=latest_prior.allergy_flag if latest_prior else False)
    with col2:
        fasting_glucose = st.number_input("Fasting glucose (mg/dL)", min_value=0.0, value=latest_prior.fasting_glucose_mgdl or 0.0 if latest_prior else 0.0)
        pp_glucose = st.number_input("Post-prandial glucose (mg/dL)", min_value=0.0, value=latest_prior.pp_glucose_mgdl or 0.0 if latest_prior else 0.0)
        hba1c = st.number_input("HbA1c (%)", min_value=0.0, max_value=20.0, value=latest_prior.hba1c_percent or 0.0 if latest_prior else 0.0, step=0.1)
        course_number = st.number_input("Course number", min_value=0, value=(latest_prior.course_number if latest_prior else 0))
        medication_brand = st.text_input("Current medication brand", value=latest_prior.medication_brand if latest_prior else "")
        protocol_reference = st.text_input("Protocol reference", value=latest_prior.protocol_reference if latest_prior else "")

    if st.button("Save Consultation", type="primary"):
        st.session_state["consultation_context"] = {
            "patient_id": patient_choice,
            "diagnosis_type": diagnosis_type,
            "comorbidity": comorbidity,
            "symptoms": symptoms,
            "allergy_flag": allergy_flag,
            "fasting_glucose_mgdl": fasting_glucose or None,
            "pp_glucose_mgdl": pp_glucose or None,
            "hba1c_percent": hba1c or None,
            "course_number": course_number or None,
            "medication_brand": medication_brand,
            "protocol_reference": protocol_reference,
        }
        st.success("Consultation details saved. Use the AI Suggestion tab or the search bar at the top next.")

    if prior_history:
        st.caption(f"Prior course history for {patient_choice}:")
        st.dataframe(
            pd.DataFrame(
                [
                    {
                        "Course": v.course_number,
                        "Date": v.visit_date,
                        "HbA1c %": v.hba1c_percent,
                        "Brand": v.medication_brand,
                        "Outcome": v.outcome_status,
                    }
                    for v in prior_history
                ]
            ),
            use_container_width=True,
        )

# ---- Tab 2: Course Tracking ----
with tabs[1]:
    st.subheader("Course Tracking")
    if patient_choice == "New patient" or not prior_history:
        st.info("Select an existing patient with course history in the Consultation tab to see KPI tracking.")
    else:
        kpis = compute_course_kpis(prior_history)
        if latest_course_needs_escalation(prior_history):
            st.warning(
                f"Escalation indicated: HbA1c did not improve enough across the most recent course "
                f"(threshold: {CONFIG.hba1c_improvement_threshold} pts). Move patient to closer observation."
            )
        else:
            st.success("No escalation currently flagged for this patient's most recent course.")

        if kpis.transitions:
            st.dataframe(
                pd.DataFrame(
                    [
                        {
                            "From Course": t.from_course,
                            "To Course": t.to_course,
                            "HbA1c Before": t.hba1c_before,
                            "HbA1c After": t.hba1c_after,
                            "Delta (improvement)": t.delta,
                            "Escalation Flagged": t.escalation_flagged,
                        }
                        for t in kpis.transitions
                    ]
                ),
                use_container_width=True,
            )
        st.caption(
            f"Courses to control (HbA1c < {7.0}%): {kpis.courses_to_control or 'not yet reached'} · "
            f"Escalation rate for this patient: {kpis.escalation_rate if kpis.escalation_rate is not None else 'N/A'}"
        )

# ---- Tab 3: AI Suggestion ----
with tabs[2]:
    st.subheader("AI Suggestion (advisory only)")
    context = st.session_state["consultation_context"]
    if not context:
        st.info("Save a consultation in the Consultation tab first.")
    else:
        st.json(context)
        if st.button("Get AI Suggestion"):
            _trace_id = tracing.new_trace_id()
            _patient_id_hash = tracing.hash_patient_id(context.get("patient_id"))
            try:
                suggestion = generate_suggestion(context, demo_mode=demo_mode_llm)
                st.session_state["last_suggestion"] = suggestion
                st.session_state["suggestion_error"] = None
                st.session_state["last_suggestion_trace_id"] = _trace_id
                tracing.append_trace(
                    tracing.TraceEvent(
                        trace_id=_trace_id,
                        timestamp=tracing.now_iso(),
                        event_type="llm_suggestion",
                        patient_id_hash=_patient_id_hash,
                        provider=suggestion.model_used,
                        is_demo=suggestion.is_demo,
                        latency_seconds=suggestion.latency_seconds,
                        status="success",
                        detail=suggestion.text[:120],
                        doctor_action="pending",
                        temperature=suggestion.temperature,
                        prompt_tokens=suggestion.prompt_tokens,
                        completion_tokens=suggestion.completion_tokens,
                        total_tokens=suggestion.total_tokens,
                    )
                )
            except LLMUnavailableError as exc:
                st.session_state["last_suggestion"] = None
                st.session_state["suggestion_error"] = str(exc)
                st.session_state["last_suggestion_trace_id"] = None
                tracing.append_trace(
                    tracing.TraceEvent(
                        trace_id=_trace_id,
                        timestamp=tracing.now_iso(),
                        event_type="llm_suggestion",
                        patient_id_hash=_patient_id_hash,
                        provider="none",
                        is_demo=False,
                        latency_seconds=0.0,
                        status="error",
                        detail="LLM request failed for all configured providers",
                        error=str(exc),
                    )
                )

        if st.session_state["suggestion_error"]:
            st.error(st.session_state["suggestion_error"])
        elif st.session_state["last_suggestion"]:
            suggestion = st.session_state["last_suggestion"]
            if suggestion.is_demo:
                st.markdown('<div class="demo-banner">Demo Mode — no LLM call was made.</div>', unsafe_allow_html=True)
            st.write(suggestion.text)
            st.caption(f"Model: {suggestion.model_used} · Latency: {suggestion.latency_seconds:.3f}s")
            if suggestion.is_demo:
                st.caption("Temperature: N/A (Demo Mode) · Tokens: N/A (Demo Mode)")
            else:
                temp_text = suggestion.temperature if suggestion.temperature is not None else "N/A"
                tokens_text = (
                    f"prompt {suggestion.prompt_tokens} + completion {suggestion.completion_tokens} "
                    f"= total {suggestion.total_tokens}"
                    if suggestion.total_tokens is not None
                    else "N/A (not reported by provider)"
                )
                st.caption(f"Temperature: {temp_text} · Tokens: {tokens_text}")
            st.caption("This is an advisory suggestion only. The treating doctor makes the final decision.")

            _trace_id = st.session_state["last_suggestion_trace_id"]
            if _trace_id:
                st.caption("Doctor decision (feeds the Suggestion Acceptance Rate KPI):")
                accept_col, edit_col, reject_col = st.columns(3)
                if accept_col.button("Accept", key="doctor_accept"):
                    tracing.update_doctor_action(_trace_id, "accepted")
                    st.success("Recorded: Accepted.")
                if edit_col.button("Edit", key="doctor_edit"):
                    tracing.update_doctor_action(_trace_id, "edited")
                    st.info("Recorded: Edited.")
                if reject_col.button("Reject", key="doctor_reject"):
                    tracing.update_doctor_action(_trace_id, "rejected")
                    st.warning("Recorded: Rejected.")

            st.divider()
            st.caption("Ask a follow-up question about this case (grounded in the same consultation details):")
            followup_question = st.text_input("Follow-up question", key="followup_question_input")
            if st.button("Ask Follow-up") and followup_question:
                _followup_trace_id = tracing.new_trace_id()
                _followup_patient_hash = tracing.hash_patient_id(context.get("patient_id"))
                try:
                    answer = answer_followup_question(
                        context, suggestion.text, followup_question, demo_mode=demo_mode_llm
                    )
                    st.session_state["followup_qa"].insert(
                        0, {"question": followup_question, "answer": answer.text, "is_demo": answer.is_demo}
                    )
                    tracing.append_trace(
                        tracing.TraceEvent(
                            trace_id=_followup_trace_id,
                            timestamp=tracing.now_iso(),
                            event_type="followup_qa",
                            patient_id_hash=_followup_patient_hash,
                            provider=answer.model_used,
                            is_demo=answer.is_demo,
                            latency_seconds=answer.latency_seconds,
                            status="success",
                            detail=answer.text[:120],
                            temperature=answer.temperature,
                            prompt_tokens=answer.prompt_tokens,
                            completion_tokens=answer.completion_tokens,
                            total_tokens=answer.total_tokens,
                        )
                    )
                except LLMUnavailableError as exc:
                    st.error(str(exc))
                    tracing.append_trace(
                        tracing.TraceEvent(
                            trace_id=_followup_trace_id,
                            timestamp=tracing.now_iso(),
                            event_type="followup_qa",
                            patient_id_hash=_followup_patient_hash,
                            provider="none",
                            is_demo=False,
                            latency_seconds=0.0,
                            status="error",
                            detail="Follow-up Q&A request failed for all configured providers",
                            error=str(exc),
                        )
                    )

            for qa in st.session_state["followup_qa"]:
                if qa["is_demo"]:
                    st.markdown('<div class="demo-banner">Demo Mode — no LLM call was made.</div>', unsafe_allow_html=True)
                st.markdown(f"**Q: {qa['question']}**")
                st.write(qa["answer"])

# ---- Tab 4: Evaluation & KPIs ----
with tabs[3]:
    st.subheader("Evaluation & KPIs")
    st.caption("Heuristic metrics — not exact ground truth unless noted.")
    context = st.session_state["consultation_context"]
    suggestion = st.session_state["last_suggestion"]
    if suggestion and context:
        ev = evaluate_suggestion(suggestion.text, context)
        cols = st.columns(3)
        cols[0].metric("Groundedness (heuristic)", f"{ev.groundedness:.3f}" if ev.groundedness is not None else "N/A")
        cols[1].metric("Relevance (heuristic)", f"{ev.relevance:.3f}" if ev.relevance is not None else "N/A")
        cols[2].metric("Suggestion Latency (s)", f"{suggestion.latency_seconds:.3f}")
    else:
        st.info("Generate a suggestion in the AI Suggestion tab to see evaluation metrics.")

# ---- Tab 5: Observability ----
with tabs[4]:
    st.subheader("Observability & Traceability")
    st.caption("Audit trail of every LLM suggestion and search call, per docs/Algent.md §7.")
    traces = tracing.load_traces(50)

    llm_traces = [t for t in traces if t["event_type"] == "llm_suggestion"]
    llm_success_rate = (
        round(sum(1 for t in llm_traces if t["status"] == "success") / len(llm_traces), 2) if llm_traces else None
    )
    acceptance_rate = tracing.suggestion_acceptance_rate(traces)

    cols = st.columns(3)
    cols[0].metric("Traces Logged", len(traces))
    cols[1].metric("LLM Success Rate", llm_success_rate if llm_success_rate is not None else "N/A")
    cols[2].metric("Suggestion Acceptance Rate", acceptance_rate if acceptance_rate is not None else "N/A")

    if traces:
        st.dataframe(
            pd.DataFrame(
                [
                    {
                        "Trace ID": t["trace_id"],
                        "Timestamp": t["timestamp"],
                        "Event": t["event_type"],
                        "Provider": t["provider"],
                        "Demo": t["is_demo"],
                        "Latency (s)": t["latency_seconds"],
                        "Status": t["status"],
                        "Doctor Action": t.get("doctor_action") or "",
                        "Temperature": str(t["temperature"]) if t.get("temperature") is not None else "N/A",
                        "Total Tokens": str(t["total_tokens"]) if t.get("total_tokens") is not None else "N/A",
                        "Detail": t["detail"],
                    }
                    for t in traces
                ]
            ),
            use_container_width=True,
        )
    else:
        st.info("No traces logged yet. Get an AI Suggestion or run a search to populate this audit trail.")

    st.divider()
    st.caption("Search past traces (semantic) — find similar past suggestions/searches in short-term memory.")
    memory_query = st.text_input(
        "Semantic search",
        placeholder="e.g. escalate diabetes course, metformin allergy alternative...",
        label_visibility="collapsed",
        key="memory_search_query",
    )
    if st.button("Search Memory") and memory_query:
        try:
            matches = memory_index.search(memory_query, tracing.load_traces(200), k=5)
        except ImportError:
            st.info("Semantic search unavailable — install faiss-cpu and sentence-transformers.")
        else:
            if not matches:
                st.info("No traces to search yet — get an AI Suggestion or run a search first.")
            else:
                st.dataframe(
                    pd.DataFrame(
                        [
                            {
                                "Score": m.score,
                                "Trace ID": m.trace_id,
                                "Event": m.event_type,
                                "Provider": m.provider,
                                "Timestamp": m.timestamp,
                                "Doctor Action": m.doctor_action or "",
                                "Detail": m.detail,
                            }
                            for m in matches
                        ]
                    ),
                    use_container_width=True,
                )

# ---- Tab 6: Data Preview ----
with tabs[5]:
    st.subheader("Data Preview")
    st.dataframe(pd.read_csv(CSV_PATH), use_container_width=True)

# ---- Tab 7: Case Summary ----
with tabs[6]:
    st.subheader("Case Summary (advisory, for the patient file)")
    context = st.session_state["consultation_context"]
    if not context:
        st.info("Save a consultation in the Consultation tab first.")
    else:
        st.caption(f"Patient: {context.get('patient_id')}")
        if st.button("Generate Case Summary"):
            _cs_trace_id = tracing.new_trace_id()
            _cs_patient_hash = tracing.hash_patient_id(context.get("patient_id"))
            try:
                summary = generate_case_summary(context, prior_history, demo_mode=demo_mode_llm)
                st.session_state["last_case_summary"] = summary
                tracing.append_trace(
                    tracing.TraceEvent(
                        trace_id=_cs_trace_id,
                        timestamp=tracing.now_iso(),
                        event_type="case_summary",
                        patient_id_hash=_cs_patient_hash,
                        provider=summary.model_used,
                        is_demo=summary.is_demo,
                        latency_seconds=summary.latency_seconds,
                        status="success",
                        detail=summary.text[:120],
                        temperature=summary.temperature,
                        prompt_tokens=summary.prompt_tokens,
                        completion_tokens=summary.completion_tokens,
                        total_tokens=summary.total_tokens,
                    )
                )
            except LLMUnavailableError as exc:
                st.session_state["last_case_summary"] = None
                st.error(str(exc))
                tracing.append_trace(
                    tracing.TraceEvent(
                        trace_id=_cs_trace_id,
                        timestamp=tracing.now_iso(),
                        event_type="case_summary",
                        patient_id_hash=_cs_patient_hash,
                        provider="none",
                        is_demo=False,
                        latency_seconds=0.0,
                        status="error",
                        detail="Case summary request failed for all configured providers",
                        error=str(exc),
                    )
                )

        summary = st.session_state["last_case_summary"]
        if summary:
            if summary.is_demo:
                st.markdown('<div class="demo-banner">Demo Mode — no LLM call was made.</div>', unsafe_allow_html=True)
            st.write(summary.text)
            st.caption(f"Model: {summary.model_used} · Latency: {summary.latency_seconds:.3f}s")
            pdf_bytes = build_case_summary_pdf(str(context.get("patient_id")), summary.text)
            st.download_button(
                "Download Case Summary (PDF)",
                data=pdf_bytes,
                file_name=f"case_summary_{context.get('patient_id')}.pdf",
                mime="application/pdf",
            )

# ---- Tab 8: Translate ----
with tabs[7]:
    st.subheader("Translate Suggestion (for patient communication)")
    last_suggestion = st.session_state["last_suggestion"]
    if not last_suggestion:
        st.info("Get an AI Suggestion in the AI Suggestion tab first.")
    else:
        st.write(last_suggestion.text)
        target_language = st.selectbox("Translate to", TRANSLATE_LANGUAGES)
        if st.button("Translate"):
            _tr_trace_id = tracing.new_trace_id()
            _tr_patient_hash = tracing.hash_patient_id(st.session_state["consultation_context"].get("patient_id"))
            try:
                translation = translate_text(last_suggestion.text, target_language, demo_mode=demo_mode_llm)
                st.session_state["last_translation"] = translation
                tracing.append_trace(
                    tracing.TraceEvent(
                        trace_id=_tr_trace_id,
                        timestamp=tracing.now_iso(),
                        event_type="translation",
                        patient_id_hash=_tr_patient_hash,
                        provider=translation.model_used,
                        is_demo=translation.is_demo,
                        latency_seconds=translation.latency_seconds,
                        status="success",
                        detail=f"-> {target_language}: {translation.text[:100]}",
                        temperature=translation.temperature,
                        prompt_tokens=translation.prompt_tokens,
                        completion_tokens=translation.completion_tokens,
                        total_tokens=translation.total_tokens,
                    )
                )
            except LLMUnavailableError as exc:
                st.session_state["last_translation"] = None
                st.error(str(exc))
                tracing.append_trace(
                    tracing.TraceEvent(
                        trace_id=_tr_trace_id,
                        timestamp=tracing.now_iso(),
                        event_type="translation",
                        patient_id_hash=_tr_patient_hash,
                        provider="none",
                        is_demo=False,
                        latency_seconds=0.0,
                        status="error",
                        detail=f"Translation to {target_language} failed for all configured providers",
                        error=str(exc),
                    )
                )

        translation = st.session_state["last_translation"]
        if translation:
            if translation.is_demo:
                st.markdown('<div class="demo-banner">Demo Mode — no LLM call was made.</div>', unsafe_allow_html=True)
            st.write(translation.text)
            st.caption(f"Model: {translation.model_used} · Latency: {translation.latency_seconds:.3f}s")
