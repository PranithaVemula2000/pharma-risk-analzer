"""Google search tool for the doctor, via Serper (serper.dev), with an offline Demo Mode.

Serper is an OpenAI/Google-Search-compatible wrapper API with a free tier (no
separate Custom Search Engine ID needed - just one API key). Demo Mode runs
whenever the caller passes demo_mode=True, OR SERPER_API_KEY is not configured.
Queries are always de-identified before either path runs (governance.md SS11) -
patient IDs never leave the app.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from app.config import CONFIG
from app.utils import timer

_PATIENT_ID_PATTERN = re.compile(r"\bPT-\d+\b", re.IGNORECASE)


class SearchUnavailableError(RuntimeError):
    """Raised when a real Serper search call is required but fails."""


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str


@dataclass
class SearchResponse:
    query: str
    results: list[SearchResult]
    is_demo: bool
    latency_seconds: float


def deidentify_query(raw_query: str) -> str:
    """Strip patient-identifying tokens (e.g. PT-1002) before a query leaves the app."""
    cleaned = _PATIENT_ID_PATTERN.sub("", raw_query)
    return re.sub(r"\s+", " ", cleaned).strip()


def _demo_results(query: str) -> list[SearchResult]:
    return [
        SearchResult(
            title=f"[DEMO] {query.title()} — clinical reference overview",
            url="https://example.org/demo-clinical-reference",
            snippet=(
                "This is a placeholder result. Set SERPER_API_KEY and turn off Demo Mode "
                "to get real search results for this query."
            ),
        ),
        SearchResult(
            title=f"[DEMO] Brand/molecule options related to: {query}",
            url="https://example.org/demo-brand-options",
            snippet="Placeholder brand-alternative listing for demonstration purposes only.",
        ),
        SearchResult(
            title="[DEMO] National/WHO advisory protocol reference",
            url="https://example.org/demo-protocol-reference",
            snippet="Placeholder protocol snippet — verify against ICMR/RSSDI/WHO sources before acting.",
        ),
    ]


def _call_serper(query: str) -> list[SearchResult]:
    import requests

    response = requests.post(
        CONFIG.serper_endpoint,
        headers={"X-API-KEY": CONFIG.serper_api_key, "Content-Type": "application/json"},
        json={"q": query, "num": CONFIG.default_search_results},
        timeout=CONFIG.google_search_timeout_seconds,
    )
    response.raise_for_status()
    items = response.json().get("organic", [])
    return [
        SearchResult(title=item.get("title", ""), url=item.get("link", ""), snippet=item.get("snippet", ""))
        for item in items
    ]


def search(raw_query: str, demo_mode: bool = False) -> SearchResponse:
    """Run a de-identified Google search via Serper, or return demo results if no key/toggled on."""
    query = deidentify_query(raw_query)

    if demo_mode or not CONFIG.serper_api_key:
        return SearchResponse(query=query, results=_demo_results(query), is_demo=True, latency_seconds=0.0)

    try:
        with timer() as t:
            results = _call_serper(query)
    except Exception as exc:  # noqa: BLE001 - normalize all search failures for the UI
        raise SearchUnavailableError(f"Serper search request failed: {exc}") from exc

    return SearchResponse(query=query, results=results, is_demo=False, latency_seconds=t["seconds"])
