"""PDF export for the case summary agent, using fpdf2 (pure Python, no system deps)."""

from __future__ import annotations

from fpdf import FPDF


def _latin1(text: str) -> str:
    """fpdf2's core fonts can only render latin-1; sanitize LLM output (em-dashes, smart quotes, etc)."""
    return text.encode("latin-1", "replace").decode("latin-1")


def build_case_summary_pdf(patient_label: str, summary_text: str) -> bytes:
    """Render a case summary into a simple one-column PDF and return its bytes."""
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, _latin1("GlucoVaidya — Case Summary"), new_x="LMARGIN", new_y="NEXT")

    pdf.set_font("Helvetica", "", 11)
    pdf.cell(0, 8, _latin1(f"Patient: {patient_label}"), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    pdf.set_font("Helvetica", "", 11)
    pdf.multi_cell(0, 6, _latin1(summary_text))

    return bytes(pdf.output())
