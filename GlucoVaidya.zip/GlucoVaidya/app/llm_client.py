"""Advisory clinical suggestion generation via Groq, OpenAI, or OpenRouter, with an offline Demo Mode.

Provider order: Groq (if GROQ_API_KEY is set, free tier) is tried first, then
OpenAI direct (if OPENAI_API_KEY is set), then OpenRouter (if OPENROUTER_API_KEY
is set, primary model then fallback models). Demo Mode runs whenever the caller
passes demo_mode=True, OR no key at all is configured — so the app is fully
usable on a web page without a real API token. The suggestion is always
advisory-only: the doctor must accept/edit/reject it.
"""

from __future__ import annotations

from dataclasses import dataclass

from app.config import CONFIG
from app.utils import timer

SYSTEM_PROMPT = (
    "You are a clinical documentation assistant for a diabetes/endocrine hospital in India. "
    "You suggest possible next steps (tests, course continuation/escalation, referral, or "
    "'no medication needed') based only on the consultation details provided. "
    "Never state a suggestion as certain fact — always phrase it as advisory, and note when "
    "information is insufficient. Cite the protocol reference given in the input when you use it. "
    "The treating doctor makes the final decision; you are not prescribing."
)

SUMMARY_SYSTEM_PROMPT = (
    "You are a clinical case-summary assistant for a diabetes/endocrine hospital in India. "
    "Summarize the patient's consultation details and course history factually and concisely, "
    "for the patient's file. Use only the information given below; never invent facts, and note "
    "clearly if information (e.g. course history) is missing. Keep it to a few short paragraphs."
)

TRANSLATE_SYSTEM_PROMPT_TEMPLATE = (
    "You are a medical translation assistant. Translate the clinical text given by the user into "
    "{language}, for a patient to read. Preserve the clinical meaning exactly — do not add, remove, "
    "or soften any fact. If a drug or medical term has no precise translation, keep the original "
    "term in parentheses after the translation."
)

FOLLOWUP_SYSTEM_PROMPT = (
    "You are a clinical documentation assistant for a diabetes/endocrine hospital in India, "
    "answering a doctor's follow-up question about one specific patient case. Answer only from the "
    "consultation details and the prior suggestion given below — never invent facts. If the given "
    "information is insufficient to answer, say so plainly. The treating doctor makes the final "
    "decision; you are not prescribing."
)


class LLMUnavailableError(RuntimeError):
    """Raised when a real LLM call is required but fails for every configured provider (not for missing keys — that auto-falls-back to Demo Mode)."""


@dataclass
class SuggestionResult:
    text: str
    is_demo: bool
    latency_seconds: float
    model_used: str
    temperature: float | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


def build_suggestion_prompt(context: dict) -> str:
    lines = [f"{key}: {value}" for key, value in context.items() if value not in (None, "", [])]
    details = "\n".join(lines) if lines else "(no consultation details entered yet)"
    return (
        f"Consultation details:\n{details}\n\n"
        "Suggest the appropriate next step (repeat test / continue course / escalate course / "
        "refer to specialist / no medication needed), referencing the protocol above if present."
    )


def build_case_summary_prompt(context: dict, history: list[dict]) -> str:
    lines = [f"{key}: {value}" for key, value in context.items() if value not in (None, "", [])]
    details = "\n".join(lines) if lines else "(no consultation details entered yet)"
    if history:
        history_lines = "\n".join(
            f"- Course {h.get('course_number')}: {h.get('visit_date')}, HbA1c {h.get('hba1c_percent')}%, "
            f"brand {h.get('medication_brand')}, outcome {h.get('outcome_status')}"
            for h in history
        )
    else:
        history_lines = "(no prior course history on record)"
    return (
        f"Consultation details:\n{details}\n\n"
        f"Course history:\n{history_lines}\n\n"
        "Write a concise clinical case summary for the patient's file."
    )


def build_followup_prompt(context: dict, prior_suggestion: str, question: str) -> str:
    lines = [f"{key}: {value}" for key, value in context.items() if value not in (None, "", [])]
    details = "\n".join(lines) if lines else "(no consultation details entered yet)"
    return (
        f"Consultation details:\n{details}\n\n"
        f"Prior suggestion given to the doctor:\n{prior_suggestion}\n\n"
        f"Doctor's follow-up question:\n{question}"
    )


def _demo_case_summary(context: dict, history: list[dict]) -> str:
    diagnosis = context.get("diagnosis_type") or "unclassified"
    lines = [
        "[DEMO MODE — no LLM call was made; this is a templated placeholder]",
        f"Diagnosis category on record: {diagnosis}.",
        f"Course history on record: {len(history)} course(s)." if history else "No prior course history on record.",
        "Set GROQ_API_KEY (or OPENAI_API_KEY / OPENROUTER_API_KEY) and turn off Demo Mode in the "
        "sidebar to get a real case summary from the LLM.",
    ]
    return "\n".join(lines)


def _demo_translation(text: str, target_language: str) -> str:
    return (
        f"[DEMO MODE — translation to {target_language} not performed; showing original text]\n{text}"
    )


def _demo_followup_answer(question: str) -> str:
    return (
        "[DEMO MODE — no LLM call was made; this is a templated placeholder]\n"
        f"Question received: {question}\n"
        "Set GROQ_API_KEY (or OPENAI_API_KEY / OPENROUTER_API_KEY) and turn off Demo Mode in the "
        "sidebar to get a real grounded answer from the LLM."
    )


def _demo_suggestion(context: dict) -> str:
    diagnosis = context.get("diagnosis_type") or "unclassified"
    course_number = context.get("course_number")
    hba1c = context.get("hba1c_percent")
    allergy = context.get("allergy_flag")

    lines = [
        "[DEMO MODE — no LLM call was made; this is a templated placeholder]",
        f"Diagnosis category on record: {diagnosis}.",
    ]
    if hba1c is not None:
        lines.append(f"Latest HbA1c: {hba1c}% — compare against the 7.0% control target.")
    if course_number:
        lines.append(f"Currently on course #{course_number}; check the Course Tracking tab for the escalation KPI.")
    if allergy:
        lines.append("Allergy flag is set — use the Google Search tab to look up an alternate brand.")
    lines.append(
        "Set GROQ_API_KEY (or OPENAI_API_KEY / OPENROUTER_API_KEY) and turn off Demo "
        "Mode in the sidebar to get a real protocol-grounded suggestion from the LLM."
    )
    return "\n".join(lines)


def _extract_usage(response) -> tuple[int | None, int | None, int | None]:
    """(prompt_tokens, completion_tokens, total_tokens) from an OpenAI-compatible response, or Nones."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return None, None, None
    return (
        getattr(usage, "prompt_tokens", None),
        getattr(usage, "completion_tokens", None),
        getattr(usage, "total_tokens", None),
    )


def _get_groq_client():
    from openai import OpenAI

    return OpenAI(base_url=CONFIG.groq_base_url, api_key=CONFIG.groq_api_key)


def _get_openai_client():
    from openai import OpenAI

    return OpenAI(api_key=CONFIG.openai_api_key)


def _get_client():
    from openai import OpenAI

    return OpenAI(base_url=CONFIG.openrouter_base_url, api_key=CONFIG.openrouter_api_key)


def _call_groq(
    client, system_prompt: str, user_prompt: str
) -> tuple[str, float, tuple[int | None, int | None, int | None]]:
    with timer() as t:
        response = client.chat.completions.create(
            model=CONFIG.groq_model_name,
            temperature=CONFIG.openrouter_temperature,
            max_tokens=CONFIG.groq_max_output_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
    return response.choices[0].message.content, t["seconds"], _extract_usage(response)


def _call_openai(
    client, system_prompt: str, user_prompt: str
) -> tuple[str, float, tuple[int | None, int | None, int | None]]:
    with timer() as t:
        response = client.chat.completions.create(
            model=CONFIG.openai_model_name,
            temperature=CONFIG.openrouter_temperature,
            max_tokens=CONFIG.openai_max_output_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
    return response.choices[0].message.content, t["seconds"], _extract_usage(response)


def _call_model(
    client, model: str, system_prompt: str, user_prompt: str
) -> tuple[str, float, tuple[int | None, int | None, int | None]]:
    with timer() as t:
        response = client.chat.completions.create(
            model=model,
            temperature=CONFIG.openrouter_temperature,
            max_tokens=CONFIG.openrouter_max_output_tokens,
            timeout=CONFIG.openrouter_timeout_seconds,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
    return response.choices[0].message.content, t["seconds"], _extract_usage(response)


def _run_agent(system_prompt: str, user_prompt: str, demo_text: str, demo_mode: bool) -> SuggestionResult:
    """Shared Groq -> OpenAI -> OpenRouter -> Demo Mode fallback chain for every agent in this module.

    Every agent (suggestion, case summary, translation, follow-up Q&A) reuses the same
    provider chain and the same API keys — only the system/user prompt differ. A
    provider/model can be temporarily unavailable (rate limit, no billing credits, an
    OpenRouter account guardrail, a de-listed endpoint) without a key or code change, so
    a single hard failure shouldn't take down real-mode calls.
    """
    if demo_mode or not (CONFIG.groq_api_key or CONFIG.openai_api_key or CONFIG.openrouter_api_key):
        return SuggestionResult(text=demo_text, is_demo=True, latency_seconds=0.0, model_used="demo")

    errors: list[str] = []

    if CONFIG.groq_api_key:
        label = f"groq:{CONFIG.groq_model_name}"
        try:
            text, latency, (prompt_tokens, completion_tokens, total_tokens) = _call_groq(
                _get_groq_client(), system_prompt, user_prompt
            )
            return SuggestionResult(
                text=text,
                is_demo=False,
                latency_seconds=latency,
                model_used=label,
                temperature=CONFIG.openrouter_temperature,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
            )
        except Exception as exc:  # noqa: BLE001 - fall through to OpenAI
            errors.append(f"{label}: {exc}")

    if CONFIG.openai_api_key:
        label = f"openai:{CONFIG.openai_model_name}"
        try:
            text, latency, (prompt_tokens, completion_tokens, total_tokens) = _call_openai(
                _get_openai_client(), system_prompt, user_prompt
            )
            return SuggestionResult(
                text=text,
                is_demo=False,
                latency_seconds=latency,
                model_used=label,
                temperature=CONFIG.openrouter_temperature,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
            )
        except Exception as exc:  # noqa: BLE001 - fall through to OpenRouter
            errors.append(f"{label}: {exc}")

    if CONFIG.openrouter_api_key:
        try:
            client = _get_client()
        except Exception as exc:  # noqa: BLE001 - client construction failure, no OpenRouter candidate can work
            errors.append(f"openrouter client setup: {exc}")
        else:
            for model in [CONFIG.openrouter_model_name, *CONFIG.openrouter_fallback_models]:
                try:
                    text, latency, (prompt_tokens, completion_tokens, total_tokens) = _call_model(
                        client, model, system_prompt, user_prompt
                    )
                except Exception as exc:  # noqa: BLE001 - try the next candidate model
                    errors.append(f"openrouter:{model}: {exc}")
                    continue
                return SuggestionResult(
                    text=text,
                    is_demo=False,
                    latency_seconds=latency,
                    model_used=f"openrouter:{model}",
                    temperature=CONFIG.openrouter_temperature,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    total_tokens=total_tokens,
                )

    raise LLMUnavailableError(
        "LLM request failed for all configured providers/models:\n" + "\n".join(errors)
    )


def generate_suggestion(context: dict, demo_mode: bool = False) -> SuggestionResult:
    """Generate an advisory next-step suggestion from the current consultation context."""
    return _run_agent(SYSTEM_PROMPT, build_suggestion_prompt(context), _demo_suggestion(context), demo_mode)


def generate_case_summary(context: dict, history: list[dict], demo_mode: bool = False) -> SuggestionResult:
    """Summarize the consultation context + course history into a case summary for the patient file."""
    return _run_agent(
        SUMMARY_SYSTEM_PROMPT,
        build_case_summary_prompt(context, history),
        _demo_case_summary(context, history),
        demo_mode,
    )


def translate_text(text: str, target_language: str, demo_mode: bool = False) -> SuggestionResult:
    """Translate clinical text (e.g. the last AI suggestion) into the given target language."""
    system_prompt = TRANSLATE_SYSTEM_PROMPT_TEMPLATE.format(language=target_language)
    return _run_agent(system_prompt, text, _demo_translation(text, target_language), demo_mode)


def answer_followup_question(
    context: dict, prior_suggestion: str, question: str, demo_mode: bool = False
) -> SuggestionResult:
    """Answer a doctor's free-form follow-up question, grounded in the same consultation context."""
    return _run_agent(
        FOLLOWUP_SYSTEM_PROMPT,
        build_followup_prompt(context, prior_suggestion, question),
        _demo_followup_answer(question),
        demo_mode,
    )
