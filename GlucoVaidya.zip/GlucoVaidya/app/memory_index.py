"""FAISS-backed semantic search over the trace log's short-term memory.

Embeds each trace's `detail` field (already de-identified/hashed by
app/tracing.py) with a local sentence-transformers model - no API key
required, consistent with GlucoVaidya's "works with zero tokens" design.
Lets a doctor/reviewer ask "have we suggested something like this before?"
against logs/trace_log.jsonl, instead of only listing it newest-first.
"""

from __future__ import annotations

from dataclasses import dataclass

_EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

_model = None


def _get_model():
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer

        _model = SentenceTransformer(_EMBEDDING_MODEL_NAME)
    return _model


@dataclass
class MemoryMatch:
    trace_id: str
    score: float
    detail: str
    event_type: str
    provider: str
    timestamp: str
    doctor_action: str | None


def build_index(traces: list[dict]):
    """Embed each trace's `detail` text and index it. (None, []) if traces is empty."""
    if not traces:
        return None, []

    import numpy as np
    import faiss

    model = _get_model()
    texts = [t.get("detail", "") for t in traces]
    embeddings = np.asarray(model.encode(texts, normalize_embeddings=True), dtype="float32")
    index = faiss.IndexFlatIP(embeddings.shape[1])  # cosine similarity via normalized inner product
    index.add(embeddings)
    return index, traces


def search(query: str, traces: list[dict], k: int = 5) -> list[MemoryMatch]:
    """Top-k traces whose `detail` text is semantically closest to `query`, highest score first."""
    if not query.strip():
        return []

    index, indexed_traces = build_index(traces)
    if index is None:
        return []

    import numpy as np

    model = _get_model()
    query_vec = np.asarray(model.encode([query], normalize_embeddings=True), dtype="float32")
    k = min(k, len(indexed_traces))
    scores, positions = index.search(query_vec, k)

    matches = []
    for score, pos in zip(scores[0], positions[0]):
        if pos < 0:
            continue
        t = indexed_traces[pos]
        matches.append(
            MemoryMatch(
                trace_id=t["trace_id"],
                score=round(float(score), 4),
                detail=t.get("detail", ""),
                event_type=t.get("event_type", ""),
                provider=t.get("provider", ""),
                timestamp=t.get("timestamp", ""),
                doctor_action=t.get("doctor_action"),
            )
        )
    return matches
