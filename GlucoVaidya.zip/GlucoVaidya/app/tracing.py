"""Observability/traceability for GlucoVaidya: a durable, append-only trace log.

Implements docs/Algent.md SS7 (Observation) at demo scope: every LLM suggestion
and every search call emits a TraceEvent, appended as one JSON line to
logs/trace_log.jsonl so it survives Streamlit reruns/restarts. Patient IDs are
never stored raw — only a short hash — matching the de-identification rule
already applied to search queries in search_client.deidentify_query.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

TRACE_LOG_PATH = Path(__file__).resolve().parent.parent / "logs" / "trace_log.jsonl"

DOCTOR_ACTIONS = ("pending", "accepted", "edited", "rejected")


def hash_patient_id(patient_id: str | None) -> str:
    """Short, non-reversible identifier for logs — never the raw patient ID."""
    if not patient_id:
        return "new_patient"
    return hashlib.sha256(patient_id.encode("utf-8")).hexdigest()[:12]


def new_trace_id() -> str:
    return uuid.uuid4().hex[:12]


@dataclass
class TraceEvent:
    trace_id: str
    timestamp: str
    event_type: str  # "llm_suggestion" | "search"
    patient_id_hash: str
    provider: str
    is_demo: bool
    latency_seconds: float
    status: str  # "success" | "error"
    detail: str
    error: str | None = None
    doctor_action: str | None = None  # only meaningful for "llm_suggestion"
    temperature: float | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def append_trace(event: TraceEvent) -> None:
    TRACE_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(TRACE_LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(asdict(event)) + "\n")


def load_traces(limit: int = 200) -> list[dict]:
    """Most-recent-first list of trace dicts; [] if nothing has been logged yet."""
    if not TRACE_LOG_PATH.exists():
        return []
    lines = TRACE_LOG_PATH.read_text(encoding="utf-8").splitlines()
    records = [json.loads(line) for line in lines if line.strip()]
    return list(reversed(records[-limit:]))


def update_doctor_action(trace_id: str, action: str) -> None:
    """Patch the doctor_action field of the matching trace record in place.

    Full read/patch/write, which is fine at this demo's log volume; a
    production audit log would append an immutable follow-up event instead.
    """
    if action not in DOCTOR_ACTIONS:
        raise ValueError(f"Unknown doctor_action: {action!r}")
    if not TRACE_LOG_PATH.exists():
        return

    lines = TRACE_LOG_PATH.read_text(encoding="utf-8").splitlines()
    updated = []
    for line in lines:
        if not line.strip():
            continue
        record = json.loads(line)
        if record.get("trace_id") == trace_id:
            record["doctor_action"] = action
        updated.append(json.dumps(record))
    TRACE_LOG_PATH.write_text("\n".join(updated) + "\n", encoding="utf-8")


def suggestion_acceptance_rate(traces: list[dict]) -> float | None:
    """accepted / (accepted + edited + rejected) over llm_suggestion traces."""
    decided = [
        t
        for t in traces
        if t.get("event_type") == "llm_suggestion" and t.get("doctor_action") in ("accepted", "edited", "rejected")
    ]
    if not decided:
        return None
    accepted = sum(1 for t in decided if t["doctor_action"] == "accepted")
    return round(accepted / len(decided), 2)
