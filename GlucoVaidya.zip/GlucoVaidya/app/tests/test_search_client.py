"""Tests for query de-identification and Demo Mode fallback."""

import pytest

from app.search_client import SearchResult, SearchUnavailableError, deidentify_query, search


def test_deidentify_query_strips_patient_id():
    assert deidentify_query("alternate brand for PT-1010 sulfa allergy") == "alternate brand for sulfa allergy"


def test_demo_fallback_when_no_key_configured(monkeypatch):
    monkeypatch.delenv("SERPER_API_KEY", raising=False)

    response = search("metformin alternative brand")

    assert response.is_demo is True
    assert response.results
    assert response.latency_seconds == 0.0


def test_demo_mode_explicit_bypasses_real_call(monkeypatch):
    monkeypatch.setenv("SERPER_API_KEY", "key")

    def _boom(query):
        raise AssertionError("_call_serper should not be called when demo_mode=True")

    monkeypatch.setattr("app.search_client._call_serper", _boom)

    response = search("metformin alternative brand", demo_mode=True)

    assert response.is_demo is True


def test_real_call_failure_raises_search_unavailable(monkeypatch):
    monkeypatch.setenv("SERPER_API_KEY", "key")

    def _boom(query):
        raise RuntimeError("simulated network error")

    monkeypatch.setattr("app.search_client._call_serper", _boom)

    with pytest.raises(SearchUnavailableError):
        search("metformin alternative brand", demo_mode=False)


def test_successful_real_call_returns_results(monkeypatch):
    monkeypatch.setenv("SERPER_API_KEY", "key")
    monkeypatch.setattr(
        "app.search_client._call_serper",
        lambda query: [SearchResult(title="Real result", url="https://example.com", snippet="snippet")],
    )

    response = search("metformin alternative brand", demo_mode=False)

    assert response.is_demo is False
    assert response.results[0].title == "Real result"
