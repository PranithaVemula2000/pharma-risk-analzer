"""Tests for course-to-course escalation KPI logic."""

from app.kpi import compute_course_kpis, latest_course_needs_escalation
from app.models import PatientVisit


def _visit(course_number: int, hba1c_percent: float | None, visit_date: str = "2026-01-01") -> PatientVisit:
    return PatientVisit(
        patient_id="PT-TEST",
        visit_date=visit_date,
        age=50,
        gender="M",
        diagnosis_type="type2",
        comorbidity="none",
        symptoms="polyuria",
        fasting_glucose_mgdl=160.0,
        pp_glucose_mgdl=230.0,
        hba1c_percent=hba1c_percent,
        tsh_miu_l=None,
        medication_brand="Glycomet",
        generic_name="metformin",
        dosage="500mg BD",
        course_number=course_number,
        course_start_date=visit_date,
        course_duration_days=90,
        allergy_flag=False,
        alternate_brand_suggested="",
        google_search_used=False,
        protocol_reference="RSSDI_2023",
        doctor_notes="",
        outcome_status="course_in_progress",
        followup_required=True,
        followup_date="",
    )


def test_no_escalation_when_hba1c_improves_enough():
    history = [_visit(1, 8.5), _visit(2, 7.8)]  # drop of 0.7, above default 0.3 threshold

    kpis = compute_course_kpis(history)

    assert kpis.transitions[0].escalation_flagged is False
    assert kpis.transitions[0].delta == 0.7


def test_escalation_flagged_when_hba1c_does_not_improve():
    history = [_visit(1, 8.1), _visit(2, 7.9)]  # drop of only 0.2, below threshold

    kpis = compute_course_kpis(history)

    assert kpis.transitions[0].escalation_flagged is True
    assert latest_course_needs_escalation(history) is True


def test_escalation_flagged_when_hba1c_worsens():
    history = [_visit(1, 7.5), _visit(2, 8.0)]

    kpis = compute_course_kpis(history)

    assert kpis.transitions[0].escalation_flagged is True
    assert kpis.transitions[0].delta == -0.5


def test_courses_to_control_detected():
    history = [_visit(1, 8.5), _visit(2, 6.9)]

    kpis = compute_course_kpis(history)

    assert kpis.courses_to_control == 2


def test_no_transitions_for_single_course():
    history = [_visit(1, 8.1)]

    kpis = compute_course_kpis(history)

    assert kpis.transitions == []
    assert kpis.escalation_rate is None
    assert latest_course_needs_escalation(history) is False
