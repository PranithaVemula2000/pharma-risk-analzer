"""Tests for CSV loading and per-patient grouping."""

from app.data_store import get_history, get_patient_ids, load_patient_visits

CSV_HEADER = (
    "patient_id,visit_date,age,gender,diagnosis_type,comorbidity,symptoms,"
    "fasting_glucose_mgdl,pp_glucose_mgdl,hba1c_percent,tsh_miu_l,medication_brand,"
    "generic_name,dosage,course_number,course_start_date,course_duration_days,"
    "allergy_flag,alternate_brand_suggested,google_search_used,protocol_reference,"
    "doctor_notes,outcome_status,followup_required,followup_date"
)

CSV_ROWS = [
    "PT-2001,2026-01-08,52,M,type2,none,polyuria,168,246,8.1,,Glycomet,metformin,500mg BD,1,2026-01-08,90,No,,No,RSSDI_2023,note1,course_in_progress,Yes,2026-04-08",
    "PT-2001,2026-04-10,52,M,type2,none,polyuria,162,238,7.9,,Glycomet Trio,metformin+glimepiride,1mg/500mg OD,2,2026-04-10,90,No,,Yes,RSSDI_2023,note2,course_escalated,Yes,2026-07-10",
    "PT-2002,2026-01-10,29,F,prediabetic,none,fatigue,108,148,6.0,,none,none,none,0,,0,No,,No,ADA_2024,note3,monitoring_no_medication,Yes,2026-04-10",
]


def _write_csv(tmp_path) -> str:
    path = tmp_path / "sample.csv"
    path.write_text(CSV_HEADER + "\n" + "\n".join(CSV_ROWS) + "\n")
    return str(path)


def test_load_patient_visits_parses_rows(tmp_path):
    visits = load_patient_visits(_write_csv(tmp_path))

    assert len(visits) == 3
    first = visits[0]
    assert first.patient_id == "PT-2001"
    assert first.hba1c_percent == 8.1
    assert first.allergy_flag is False
    assert first.tsh_miu_l is None


def test_load_patient_visits_parses_boolean_flags(tmp_path):
    visits = load_patient_visits(_write_csv(tmp_path))

    second = visits[1]
    assert second.google_search_used is True
    assert second.followup_required is True


def test_get_patient_ids_returns_sorted_unique(tmp_path):
    visits = load_patient_visits(_write_csv(tmp_path))

    assert get_patient_ids(visits) == ["PT-2001", "PT-2002"]


def test_get_history_sorted_by_course_number(tmp_path):
    visits = load_patient_visits(_write_csv(tmp_path))

    history = get_history(visits, "PT-2001")

    assert [v.course_number for v in history] == [1, 2]
    assert history[1].outcome_status == "course_escalated"
