"""Tests for the observability/traceability trace log."""

from app import tracing
from app.tracing import TraceEvent, append_trace, hash_patient_id, load_traces, suggestion_acceptance_rate, update_doctor_action


def _event(trace_id: str, event_type: str = "llm_suggestion", doctor_action: str | None = "pending") -> TraceEvent:
    return TraceEvent(
        trace_id=trace_id,
        timestamp=tracing.now_iso(),
        event_type=event_type,
        patient_id_hash=hash_patient_id("PT-1002"),
        provider="groq:openai/gpt-oss-120b",
        is_demo=False,
        latency_seconds=1.23,
        status="success",
        detail="some suggestion text",
        doctor_action=doctor_action,
    )


def test_hash_patient_id_never_returns_raw_input():
    hashed = hash_patient_id("PT-1002")
    assert hashed != "PT-1002"
    assert "PT-1002" not in hashed


def test_hash_patient_id_deterministic_and_handles_none():
    assert hash_patient_id("PT-1002") == hash_patient_id("PT-1002")
    assert hash_patient_id(None) == "new_patient"


def test_append_and_load_traces_round_trip(tmp_path, monkeypatch):
    monkeypatch.setattr(tracing, "TRACE_LOG_PATH", tmp_path / "trace_log.jsonl")

    append_trace(_event("aaa111"))
    append_trace(_event("bbb222"))

    traces = load_traces()

    assert len(traces) == 2
    assert traces[0]["trace_id"] == "bbb222"  # newest first
    assert traces[1]["trace_id"] == "aaa111"


def test_load_traces_returns_empty_when_no_log_file(tmp_path, monkeypatch):
    monkeypatch.setattr(tracing, "TRACE_LOG_PATH", tmp_path / "does_not_exist.jsonl")

    assert load_traces() == []


def test_update_doctor_action_patches_only_matching_trace(tmp_path, monkeypatch):
    monkeypatch.setattr(tracing, "TRACE_LOG_PATH", tmp_path / "trace_log.jsonl")

    append_trace(_event("aaa111"))
    append_trace(_event("bbb222"))

    update_doctor_action("aaa111", "accepted")
    traces = {t["trace_id"]: t for t in load_traces()}

    assert traces["aaa111"]["doctor_action"] == "accepted"
    assert traces["bbb222"]["doctor_action"] == "pending"


def test_suggestion_acceptance_rate_none_when_nothing_decided(tmp_path, monkeypatch):
    monkeypatch.setattr(tracing, "TRACE_LOG_PATH", tmp_path / "trace_log.jsonl")

    append_trace(_event("aaa111"))

    assert suggestion_acceptance_rate(load_traces()) is None


def test_suggestion_acceptance_rate_computed_over_decided_traces(tmp_path, monkeypatch):
    monkeypatch.setattr(tracing, "TRACE_LOG_PATH", tmp_path / "trace_log.jsonl")

    append_trace(_event("aaa111", doctor_action="accepted"))
    append_trace(_event("bbb222", doctor_action="rejected"))
    append_trace(_event("ccc333", doctor_action="pending"))
    append_trace(_event("ddd444", event_type="search", doctor_action=None))

    assert suggestion_acceptance_rate(load_traces()) == 0.5
