"""Tests for FAISS semantic search over the trace log's short-term memory."""

from app.memory_index import build_index, search


def _trace(trace_id: str, detail: str, event_type: str = "llm_suggestion") -> dict:
    return {
        "trace_id": trace_id,
        "timestamp": "2026-09-19T10:00:00+00:00",
        "event_type": event_type,
        "patient_id_hash": "5cac6d2cfaae",
        "provider": "groq:openai/gpt-oss-120b",
        "is_demo": False,
        "latency_seconds": 1.2,
        "status": "success",
        "detail": detail,
        "error": None,
        "doctor_action": "pending",
    }


def test_build_index_empty_returns_none():
    index, traces = build_index([])
    assert index is None
    assert traces == []


def test_search_empty_query_returns_empty():
    traces = [_trace("a1", "Escalate diabetes course, HbA1c not improving.")]
    assert search("", traces) == []


def test_search_no_traces_returns_empty():
    assert search("diabetes escalation", []) == []


def test_search_ranks_semantically_closest_trace_first():
    traces = [
        _trace("derm1", "Suggest an alternative brand for a skin allergy rash cream."),
        _trace("diab1", "Escalate diabetes course, HbA1c not improving after treatment."),
    ]

    matches = search("Should we escalate this patient's diabetes treatment course?", traces, k=2)

    assert len(matches) == 2
    assert matches[0].trace_id == "diab1"
    assert matches[0].score > matches[1].score


def test_search_respects_k_limit():
    traces = [_trace(f"t{i}", f"Detail number {i} about diabetes course tracking") for i in range(5)]

    matches = search("diabetes course", traces, k=3)

    assert len(matches) == 3
