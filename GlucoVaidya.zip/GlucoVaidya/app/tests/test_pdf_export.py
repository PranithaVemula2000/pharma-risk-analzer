"""Tests for the case summary PDF export."""

from app.pdf_export import build_case_summary_pdf


def test_build_case_summary_pdf_returns_pdf_bytes():
    pdf_bytes = build_case_summary_pdf("PAT-001", "Patient is stable on course 1, HbA1c 8.1%.")

    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 0
    assert pdf_bytes.startswith(b"%PDF")


def test_build_case_summary_pdf_handles_unicode_without_crashing():
    summary = "Patient's HbA1c improved — doctor noted “good progress” this course."

    pdf_bytes = build_case_summary_pdf("PAT-002", summary)

    assert pdf_bytes.startswith(b"%PDF")
