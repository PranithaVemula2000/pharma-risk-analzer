"""Tests for Demo Mode fallback and OpenRouter failure handling."""

from unittest.mock import MagicMock

import pytest

from app.llm_client import (
    LLMUnavailableError,
    answer_followup_question,
    generate_case_summary,
    generate_suggestion,
    translate_text,
)


def _context():
    return {"diagnosis_type": "type2", "hba1c_percent": 8.1, "course_number": 1}


def _history():
    return [{"course_number": 1, "visit_date": "2026-01-10", "hba1c_percent": 8.1, "medication_brand": "Glimix", "outcome_status": "ongoing"}]


def test_demo_mode_auto_when_no_api_key(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    result = generate_suggestion(_context())

    assert result.is_demo is True
    assert result.model_used == "demo"
    assert result.latency_seconds == 0.0
    assert "type2" in result.text


def test_demo_mode_explicit_bypasses_real_call_even_with_key(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")

    def _boom():
        raise AssertionError("_get_groq_client should not be called when demo_mode=True")

    monkeypatch.setattr("app.llm_client._get_groq_client", _boom)

    result = generate_suggestion(_context(), demo_mode=True)

    assert result.is_demo is True


def test_real_call_failure_raises_llm_unavailable(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("OPENROUTER_API_KEY", "test-key")

    def _boom():
        raise RuntimeError("simulated timeout")

    monkeypatch.setattr("app.llm_client._get_groq_client", _boom)
    monkeypatch.setattr("app.llm_client._get_openai_client", _boom)
    monkeypatch.setattr("app.llm_client._get_client", _boom)

    with pytest.raises(LLMUnavailableError):
        generate_suggestion(_context(), demo_mode=False)


def test_successful_groq_call_returns_text(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    fake_client = MagicMock()
    fake_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="Repeat fasting glucose test in 2 weeks."))]
    )
    monkeypatch.setattr("app.llm_client._get_groq_client", lambda: fake_client)

    result = generate_suggestion(_context(), demo_mode=False)

    assert result.is_demo is False
    assert result.model_used.startswith("groq:")
    assert "Repeat fasting glucose" in result.text


def test_groq_failure_falls_back_to_openai(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    def _boom_groq():
        raise RuntimeError("groq unavailable")

    fake_openai_client = MagicMock()
    fake_openai_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="Continue current course, recheck HbA1c in 6 weeks."))]
    )

    monkeypatch.setattr("app.llm_client._get_groq_client", _boom_groq)
    monkeypatch.setattr("app.llm_client._get_openai_client", lambda: fake_openai_client)

    result = generate_suggestion(_context(), demo_mode=False)

    assert result.is_demo is False
    assert result.model_used.startswith("openai:")
    assert "Continue current course" in result.text


def test_successful_openai_call_returns_text(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    fake_client = MagicMock()
    fake_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="Continue current course, recheck HbA1c in 6 weeks."))]
    )
    monkeypatch.setattr("app.llm_client._get_openai_client", lambda: fake_client)

    result = generate_suggestion(_context(), demo_mode=False)

    assert result.is_demo is False
    assert result.model_used.startswith("openai:")
    assert "Continue current course" in result.text


def test_openai_failure_falls_back_to_openrouter(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("OPENROUTER_API_KEY", "test-key")

    def _boom_openai():
        raise RuntimeError("openai unavailable")

    fake_openrouter_client = MagicMock()
    fake_openrouter_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="Escalate to specialist referral."))]
    )

    monkeypatch.setattr("app.llm_client._get_openai_client", _boom_openai)
    monkeypatch.setattr("app.llm_client._get_client", lambda: fake_openrouter_client)

    result = generate_suggestion(_context(), demo_mode=False)

    assert result.is_demo is False
    assert result.model_used.startswith("openrouter:")
    assert "Escalate to specialist" in result.text


def test_case_summary_demo_mode(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    result = generate_case_summary(_context(), _history())

    assert result.is_demo is True
    assert "type2" in result.text


def test_case_summary_successful_groq_call(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    fake_client = MagicMock()
    fake_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="Patient on course 1, HbA1c 8.1%, ongoing."))]
    )
    monkeypatch.setattr("app.llm_client._get_groq_client", lambda: fake_client)

    result = generate_case_summary(_context(), _history(), demo_mode=False)

    assert result.is_demo is False
    assert result.model_used.startswith("groq:")
    assert "ongoing" in result.text


def test_translate_demo_mode(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    result = translate_text("Continue current course.", "Hindi")

    assert result.is_demo is True
    assert "Continue current course" in result.text


def test_translate_successful_groq_call(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    fake_client = MagicMock()
    fake_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="हिन्दी अनुवाद"))]
    )
    monkeypatch.setattr("app.llm_client._get_groq_client", lambda: fake_client)

    result = translate_text("Continue current course.", "Hindi", demo_mode=False)

    assert result.is_demo is False
    assert result.model_used.startswith("groq:")


def test_followup_qa_demo_mode(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    result = answer_followup_question(_context(), "Repeat fasting glucose test.", "Why this test?")

    assert result.is_demo is True
    assert "Why this test?" in result.text


def test_followup_qa_successful_groq_call(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    fake_client = MagicMock()
    fake_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="Because HbA1c is above the 7.0% control target."))]
    )
    monkeypatch.setattr("app.llm_client._get_groq_client", lambda: fake_client)

    result = answer_followup_question(
        _context(), "Repeat fasting glucose test.", "Why this test?", demo_mode=False
    )

    assert result.is_demo is False
    assert result.model_used.startswith("groq:")
    assert "control target" in result.text


def test_real_call_failure_raises_for_case_summary(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

    def _boom():
        raise RuntimeError("simulated timeout")

    monkeypatch.setattr("app.llm_client._get_groq_client", _boom)

    with pytest.raises(LLMUnavailableError):
        generate_case_summary(_context(), _history(), demo_mode=False)
