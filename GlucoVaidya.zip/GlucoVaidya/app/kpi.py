"""Course-to-course KPI logic: HbA1c delta and escalation-needed flagging.

Implements Scenario 2 from docs/problemstatement.md: if HbA1c does not improve
enough across a completed medication course, the next course is flagged as an
escalation, and the patient should be moved to closer observation.
"""

from __future__ import annotations

from dataclasses import dataclass

from app.config import CONFIG
from app.models import PatientVisit

HBA1C_CONTROL_TARGET = 7.0  # widely used clinical target, RSSDI/ADA-aligned


@dataclass
class CourseTransition:
    from_course: int
    to_course: int
    hba1c_before: float | None
    hba1c_after: float | None
    delta: float | None  # positive = improvement (HbA1c went down)
    escalation_flagged: bool


@dataclass
class CourseKPIs:
    total_courses: int
    transitions: list[CourseTransition]
    courses_to_control: int | None  # course_number at which HbA1c first reached target, else None
    escalation_rate: float | None  # fraction of transitions flagged as escalation


def _delta(before: float | None, after: float | None) -> float | None:
    if before is None or after is None:
        return None
    return round(before - after, 2)


def compute_course_kpis(history: list[PatientVisit]) -> CourseKPIs:
    """history must be sorted by course_number ascending (see data_store.get_history)."""
    transitions: list[CourseTransition] = []
    for prev, curr in zip(history, history[1:]):
        delta = _delta(prev.hba1c_percent, curr.hba1c_percent)
        escalation_flagged = delta is not None and delta < CONFIG.hba1c_improvement_threshold
        transitions.append(
            CourseTransition(
                from_course=prev.course_number,
                to_course=curr.course_number,
                hba1c_before=prev.hba1c_percent,
                hba1c_after=curr.hba1c_percent,
                delta=delta,
                escalation_flagged=escalation_flagged,
            )
        )

    courses_to_control = next(
        (v.course_number for v in history if v.hba1c_percent is not None and v.hba1c_percent < HBA1C_CONTROL_TARGET),
        None,
    )

    escalation_rate = (
        sum(1 for t in transitions if t.escalation_flagged) / len(transitions) if transitions else None
    )

    return CourseKPIs(
        total_courses=len({v.course_number for v in history}),
        transitions=transitions,
        courses_to_control=courses_to_control,
        escalation_rate=escalation_rate,
    )


def latest_course_needs_escalation(history: list[PatientVisit]) -> bool:
    """Quick check used for the Course Tracking banner: does the most recent course need escalation?"""
    kpis = compute_course_kpis(history)
    return bool(kpis.transitions and kpis.transitions[-1].escalation_flagged)
