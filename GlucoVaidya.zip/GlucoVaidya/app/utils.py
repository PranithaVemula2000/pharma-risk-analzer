"""Small shared helpers."""

from __future__ import annotations

import time
from contextlib import contextmanager


@contextmanager
def timer():
    """Yields a dict that is filled with elapsed seconds on exit: `with timer() as t: ...; t["seconds"]`."""
    result: dict[str, float] = {"seconds": 0.0}
    start = time.perf_counter()
    try:
        yield result
    finally:
        result["seconds"] = time.perf_counter() - start
