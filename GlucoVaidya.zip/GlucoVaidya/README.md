# GlucoVaidya — Hospital Helper Tool

A doctor-facing clinical documentation and advisory assistant for a diabetes/endocrine
hospital, built as a standalone Streamlit app. See `docs/problemstatement.md`,
`docs/governance.md`, and `docs/Algent.md` for the full design background.

## Stack

- Streamlit UI
- Groq (`openai/gpt-oss-120b`, free tier, OpenAI-compatible API) for advisory
  suggestions — tried first when configured
- OpenAI direct (`gpt-4o-mini`) as a secondary suggestion provider
- OpenRouter (`openai/gpt-oss-120b` + fallback models) as a tertiary suggestion provider
- Serper (serper.dev, has a free tier) for the doctor-assist Google search tab
- Pandas for the course/consultation dataset (`data/sample_patient_data.csv`)
- FAISS + local `sentence-transformers/all-MiniLM-L6-v2` embeddings for semantic
  search over the trace log's short-term memory (`logs/trace_log.jsonl`) — no API
  key required
- Three additional fixed-purpose agents (case summary, translation, follow-up
  Q&A) reuse the same Groq/OpenAI/OpenRouter provider chain and keys as the
  main suggestion agent — no extra key needed
- `fpdf2` for exporting the case summary as a downloadable PDF
- Pytest for testing

## Demo Mode — runs with no API tokens at all

Both external calls (LLM suggestion, Google Search) have a **Demo Mode**:

- If none of `GROQ_API_KEY`, `OPENAI_API_KEY`, or `OPENROUTER_API_KEY` is set, the
  sidebar's "Demo Mode (LLM)" checkbox is auto-checked and suggestions are generated
  locally from the consultation context — no network call, clearly labeled
  `[DEMO MODE]` in the output. When a key is set, providers are tried in order
  (Groq, then OpenAI, then OpenRouter); if a call fails it falls through to the next
  configured provider before giving up.
- If `SERPER_API_KEY` is not set, "Demo Mode (Search)" is auto-checked and a canned
  placeholder result list is shown instead.
- Either checkbox can be toggled manually regardless of whether keys are present.

This means the app is fully clickable/demoable on a web page with zero API tokens.

## Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# optionally edit .env:
#   GROQ_API_KEY=...         (https://console.groq.com — free tier, recommended real provider)
#   OPENAI_API_KEY=...       (https://platform.openai.com — optional secondary provider)
#   OPENROUTER_API_KEY=...   (https://openrouter.ai — optional tertiary provider)
#   SERPER_API_KEY=...       (https://serper.dev — free tier, one API key, no CSE setup)
```

## Run

```bash
streamlit run app/app.py
```

1. **Search bar** (always visible, top of page) — type a query and press Enter, or
   click Search; de-identified query, real (Serper) or Demo Mode results.
2. **Consultation** tab — pick an existing patient (loaded from the sample CSV) or
   enter a new one; save the consultation context.
3. **Course Tracking** tab — see course-to-course HbA1c deltas and the
   escalation-needed KPI (Scenario 2 in `docs/problemstatement.md`).
4. **AI Suggestion** tab — get an advisory-only suggestion (real or Demo Mode), then
   record the doctor's Accept / Edit / Reject decision. Includes a follow-up Q&A box
   to ask grounded questions about the same case.
5. **Evaluation & KPIs** tab — heuristic groundedness/relevance of the last suggestion.
6. **Observability** tab — audit trail of every LLM suggestion and search call
   (provider, latency, status, doctor decision), persisted to `logs/trace_log.jsonl`
   (hashed patient IDs and de-identified queries only — see `docs/Algent.md` §7).
   Includes a "Search past traces (semantic)" box that runs a local FAISS +
   sentence-transformers similarity search over that trace log — no API key
   needed — to find past suggestions/searches like the current one.
7. **Data Preview** tab — the raw loaded dataset.
8. **Case Summary** tab — summarize the full case (consultation + course history) into
   a case-file summary, downloadable as a PDF.
9. **Translate** tab — translate the last AI suggestion into a doctor-picked Indian
   language for patient communication.

## Testing

```bash
pytest
```

All tests run fully offline — Demo Mode paths and mocked real-call failures/successes,
no real OpenRouter or Google Search network calls.

## Important limits (see `docs/governance.md`)

- The AI suggestion is **advisory only** — it never finalizes a diagnosis or prescription.
- Search queries are de-identified (patient IDs stripped) before either the real or
  demo search path runs.
- `data/sample_patient_data.csv` is synthetic demo data — no real patient records.
